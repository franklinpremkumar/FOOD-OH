import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:foodie_app/Rounded_password_field.dart';
import 'package:foodie_app/background.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:foodie_app/main.dart';
import 'package:foodie_app/rounded_input_field.dart';
import 'package:foodie_app/roundedbutton.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:foodie_app/Models/MAPCONFIG.DART';


import 'package:foodie_app/center_page.dart';

class Body extends StatelessWidget {
  TextEditingController emailTextEditingController = TextEditingController();
  TextEditingController passwordTextEditingController = TextEditingController();
  @override
  Widget build(BuildContext context) 
  {
    Size size = MediaQuery.of(context).size;
    return Background(
        child: SingleChildScrollView(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Align(
              alignment: Alignment.bottomCenter,
              child: Text(
                "Food-OH",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 36.0,
                  fontStyle: FontStyle.italic,
                ),
              ),
            ),
          ),
          Image.asset(
            "assets/images/login1.png",
            height: 500,
            width: 500,
          ),
          SizedBox(
                  height: 30.0,
                ),
                TextField(
                  controller: emailTextEditingController,
                  keyboardType: TextInputType.emailAddress,
                  decoration: InputDecoration(
                    labelText: "Enter your email",
                    labelStyle: TextStyle(
                      fontSize: 14.0,
                    ),
                    hintStyle: TextStyle(
                      color: Colors.blueGrey,
                      fontSize: 14.0,
                    ),
                  ),
                  style: TextStyle(fontSize: 14.0),
                ),
                SizedBox(
                  height: 30.0,
                ),
                TextField(
                  controller: passwordTextEditingController,
                  keyboardType: TextInputType.visiblePassword,
                  decoration: InputDecoration(
                    labelText: "Enter your password",
                    labelStyle: TextStyle(
                      fontSize: 14.0,
                    ),
                    hintStyle: TextStyle(
                      color: Colors.blueGrey,
                      fontSize: 14.0,
                    ),
                  ),
                  style: TextStyle(fontSize: 14.0),
                ),
          // RoundedInputField(
          //   hintText: "Your Mail",
          //   onChanged: (value) {},
          // ),
          // RoundedPasswordField(
          //   onChanged: (value) {},
          // ),
         RaisedButton(
                  color: Colors.blue,
                  textColor: Colors.black,
                  child: Container(
                    height: 50.0,
                    child: Center(
                      child: Text(
                        "LOGIN",
                        style: TextStyle(fontSize: 18.0),
                      ),
                    ),
                  ),
                  onPressed: () async {
                    displayToastMessage("LOGIN SUCCESSFUL", context);
                    registerUser(context);
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (context) => CenterPage(title: "FOOD-OH",))
                      );

                  }
          )
        ],
      ),
    ));
  }

final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;
  void registerUser(BuildContext context) async {
   
      final User firebaseUser = (await _firebaseAuth
            .createUserWithEmailAndPassword(
                email: emailTextEditingController.text,
                password: passwordTextEditingController.text)
            .catchError((errMsg) {
      displayToastMessage("Error: " + errMsg.toString(), context);
    })).user;

    if (firebaseUser != null) {
      Map userDatamap = {
        "email": emailTextEditingController.text,
      };
      usersRef.child(firebaseUser.uid).set(userDatamap);
      currentfirebaseUser = firebaseUser;
    
  }
}
  
  displayToastMessage(String message, BuildContext context) {
    Fluttertoast.showToast(msg: message);
  }
}