//import 'dart:js';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:foodie_app/main.dart';
import 'Models/restaurants.dart';
import 'dish_page.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:foodie_app/center_page.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:foodie_app/Models/MAPCONFIG.DART';
import 'package:foodie_app/body.dart';


class Cart extends StatefulWidget {
  final List<FoodItems> _cart;
  List<Restaurants> parsedRestaurants;
  int currentId;
  

  Cart(this._cart);
  @override
  _CartState createState() => _CartState(this._cart);
}

class _CartState extends State<Cart> {
  _CartState(this._cart);

  List<FoodItems> _cart;
  //List<Restaurants> parsedRestaurants;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Cart'),
      ),
      body: Column(mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          SizedBox(
            height: 4.0,
          ),
          Text(
            "ITEMS ADDED IN YOUR CART",
            style: TextStyle(fontSize: 24.0,color: Colors.redAccent),
            
            textAlign: TextAlign.left,
          ),
          ListView.builder(
            
            shrinkWrap: true,
            itemCount: _cart.length,
            itemBuilder: (context, index) {
              //var firstAddedRestaurant = this._cart.where((element) => element.id == this.firstAddedRestId).first;
              //var currentid1= 
              var item = _cart[index];
              //var restaurant = parsedRestaurants[];
              //var restaurant = parsedRestaurants[index];
              return Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8.0, vertical: 2.0),
                child: Card(
                  elevation: 4.0,
                  child: ListTile(
                    leading: Icon(
                      Icons.whatshot,
                      color: Colors.red,
                    ),
                    title: Text(item.name),
                    subtitle: Text( item.name + item.price + 'dollars',),
                  
                    trailing: GestureDetector(
                        child: Icon(
                          Icons.remove_circle,
                          color: Colors.red,
                        ),
                        onTap: () {
                          setState(() {
                            _cart.remove(item);
                          });
                        }),
                  ),
                ),
                
              );
            }),
            SizedBox(
                  height: 50.0,
                ),
                RaisedButton(
                  color: Colors.blue,
                  textColor: Colors.black,
                  child: Container(
                    height: 50.0,
                    child: Center(
                      child: Text(
                        "PLACE ORDER",
                        style: TextStyle(fontSize: 18.0),
                      ),
                    ),
                  ),
                  onPressed: () async {

                    displayToastMessage("Order placed Successfully", context);
                  }  
      ),
        ]
      ),
    );
  }
  
}


displayToastMessage(String message, BuildContext context) {
    Fluttertoast.showToast(msg: message);
  }
