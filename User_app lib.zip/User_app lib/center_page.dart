import 'dart:convert';
//import 'dart:js';
import 'package:foodie_app/main.dart';
import 'package:flutter/material.dart';
import 'package:foodie_app/Models/restaurants.dart';
import 'package:foodie_app/body.dart';
import 'cart.dart';
import 'dish_page.dart';
import 'package:foodie_app/constants.dart';
import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:foodie_app/Models/MAPCONFIG.DART';
import 'package:http/http.dart' as http;


class CenterPage extends StatefulWidget {
  CenterPage({Key key, this.title}) : super(key: key);
  final String title;

  @override
  _CenterPageState createState() => _CenterPageState();
}

class _CenterPageState extends State<CenterPage> {
  // List<Dish> _dishes = List<Dish>();

  List<FoodItems> _cartList = List<FoodItems>();

  List<String> jsonRestaurants = new List<String>();
  List<Restaurants> parsedRestaurants = new List<Restaurants>();
  Restaurants entity;
  String currentPage = 'Restaurant Screen';

  int currentId;
  int firstAddedRestId;


  setCurrentPage(String currentPage) {
      setState(() {
        this.currentPage = currentPage;
      });
  }

  String sampleJson = '{"image":"https://image.shutterstock.com/image-photo/villefranche-sur-saone-france-may-600w-284572697.jpg","id":1,"name":"subway","address":"150 Saint-Catherine St W Level 72, Montreal, Quebec H5B 1B9, Canada","location":"H5B 1B9","fooditems":[{"name":"Footlong cheese and sub","price":"12.49 "},{"name":"Roasted chicken sub","price":"12.19 "},{"name":"6 inch steak and cheese sub","price":"8.39 "},{"name":"footlong italian BMT combo","price":"15.19 "},{"name":"footlong veggie delight sub","price":"8.59 "},{"name":"6 inch sweet onion sub","price":"7.89 "},{"name":"6 inch over Roasted chicken sub","price":"7.79 "},{"name":"6 inch turkey breast sub","price":"6.89 "},{"name":"6 inch italian BMT sub","price":"6.89 "},{"name":"tuna salad","price":"6.69 "},{"name":"6 inch black forest Ham sub","price":"5.59 "},{"name":"6inch veggie delite sub","price":"5.29 "},{"name":"chicken caesar wrap","price":"8.39 "},{"name":"chicken caesar wrap grand","price":"10.69 "},{"name":"chipotle guac wrap","price":"8.39 "},{"name":"turkey bacon and guac wrap","price":"8.39 "},{"name":"black forest ham salad","price":"7.89 "},{"name":"cold cut combo salad","price":"7.89 "},{"name":"sweet onion and chicken teriyaki  salad","price":"10.19 "},{"name":"Italian BMT salad","price":"9.19 "},{"name":"Oven roasted chicken salad","price":"10.19 "},{"name":"turkey breast salad","price":"9.19 "},{"name":"steak and cheese salad","price":"10.69 "},{"name":"veggie delite salad","price":"7.59 "},{"name":"six cookies","price":"6.19 "},{"name":"twelve cookies","price":"7.49 "},{"name":"doritos nachos cheese","price":"2.19 "},{"name":"Lays classic","price":"2.19 "},{"name":"baked Lay  s","price":"2.19 "},{"name":"chocolate chunk cookies","price":"1.19 "},{"name":"choco chunk with M&M cookies","price":"1.19 "},{"name":"pepsi","price":"2.99 "},{"name":"tropicana","price":"2.99 "},{"name":"diet pepsi","price":"2.99 "},{"name":"lemon iced tea","price":"2.99 "},{"name":"gatorade fruit punch","price":"2.99 "},{"name":"aquafina water","price":"2.99 "}],"openingtime":"9 AM","closingtime":"10 PM","nearbyresturantsidifordered":[{"id":2},{"id":3},{"id":4},{"id":5},{"id":6},{"id":7}]}';

  @override
  void initState() {
    super.initState();
    // _populateDishes();
    jsonRestaurants.add('{"image":"https://image.shutterstock.com/image-photo/villefranche-sur-saone-france-may-600w-284572697.jpg","id":1,"name":"SUBWAY","address":"150 Saint-Catherine St W Level 72, Montreal, Quebec H5B 1B9, Canada","location":"8.913850, 77.384386","fooditems":[{"name":"Footlong cheese and sub","price":"12.49 "},{"name":"Roasted chicken sub","price":"12.19 "},{"name":"6 inch steak and cheese sub","price":"8.39 "},{"name":"footlong italian BMT combo","price":"15.19 "},{"name":"footlong veggie delight sub","price":"8.59 "},{"name":"6 inch sweet onion sub","price":"7.89 "},{"name":"6 inch over Roasted chicken sub","price":"7.79 "},{"name":"6 inch turkey breast sub","price":"6.89 "},{"name":"6 inch italian BMT sub","price":"6.89 "},{"name":"tuna salad","price":"6.69 "},{"name":"6 inch black forest Ham sub","price":"5.59 "},{"name":"6inch veggie delite sub","price":"5.29 "},{"name":"chicken caesar wrap","price":"8.39 "},{"name":"chicken caesar wrap grand","price":"10.69 "},{"name":"chipotle guac wrap","price":"8.39 "},{"name":"turkey bacon and guac wrap","price":"8.39 "},{"name":"black forest ham salad","price":"7.89 "},{"name":"cold cut combo salad","price":"7.89 "},{"name":"sweet onion and chicken teriyaki  salad","price":"10.19 "},{"name":"Italian BMT salad","price":"9.19 "},{"name":"Oven roasted chicken salad","price":"10.19 "},{"name":"turkey breast salad","price":"9.19 "},{"name":"steak and cheese salad","price":"10.69 "},{"name":"veggie delite salad","price":"7.59 "},{"name":"six cookies","price":"6.19 "},{"name":"twelve cookies","price":"7.49 "},{"name":"doritos nachos cheese","price":"2.19 "},{"name":"Lays classic","price":"2.19 "},{"name":"baked Lay  s","price":"2.19 "},{"name":"chocolate chunk cookies","price":"1.19 "},{"name":"choco chunk with M&M cookies","price":"1.19 "},{"name":"pepsi","price":"2.99 "},{"name":"tropicana","price":"2.99 "},{"name":"diet pepsi","price":"2.99 "},{"name":"lemon iced tea","price":"2.99 "},{"name":"gatorade fruit punch","price":"2.99 "},{"name":"aquafina water","price":"2.99 "}],"openingtime":"9 AM","closingtime":"10 PM","nearbyresturantsidifordered":[{"id":2},{"id":3},{"id":4},{"id":5},{"id":6},{"id":7}]}');
     jsonRestaurants.add('{"image":"https://image.shutterstock.com/image-photo/fresh-fruits-vegetables-jamaica-260nw-795616123.jpg","id":2,"name":"Urban bites","address":"3717 St Urbain St, Montreal, Quebec H2X 2P5, Canada","location":"8.91385, 77.3986","fooditems":[{"name":"porc jerk","price":"18 "},{"name":"oxtail","price":"22 "},{"name":"jerk chicken","price":"17 "},{"name":"curry chicken","price":"17 "},{"name":"tofu jerk","price":"17 "},{"name":"curry vegitable rotti","price":"15 "},{"name":"jerk chicken rotti","price":"15 "},{"name":"jerk vegitable rotti","price":"15 "},{"name":"curry goat rotti","price":"17 "},{"name":"beef patties","price":"4 "},{"name":"chicken patties","price":"4 "},{"name":"vegetable patties","price":"4 "},{"name":"coconut water","price":"3 "},{"name":"ginger beer","price":"3 "},{"name":"grace cola champagne","price":"3 "},{"name":"pink grapefruit","price":"3 "},{"name":"coca cola","price":"2 "},{"name":"pepsi","price":"2 "},{"name":"7 up","price":"2 "},{"name":"water","price":"1.25 "}],"openingtime":"3 PM","closingtime":"8 PM","nearbyresturantsidifordered":[{"id":1},{"id":3},{"id":4},{"id":5},{"id":6},{"id":7}]}');
    jsonRestaurants.add('{"image":"https://image.shutterstock.com/image-photo/hot-homemade-pepperoni-pizza-ready-260nw-225746563.jpg","id":3,"name":"PIZZA PIZZA","address":"1846 Rue Sainte-Catherine, Montreal, QC H3H 1M1","location":"H3H 1M1","fooditems":[{"name":"create your own crest pizza","price":"14.29 "},{"name":"keto pepperoni","price":"15.49 "},{"name":"keto protein lovers","price":"17.49 "},{"name":"keto presto margherita","price":"16.49 "},{"name":"10 pc wings + dip","price":"13.48 "},{"name":"10 pc classic wings","price":"22.28 "},{"name":"10 pc classic wings + small pizza","price":"25.28 "},{"name":"10 pc classic wings + sausage mushroom melt","price":"23.78 "},{"name":"10 pc classic wings + small garden veggie pizza","price":"25.28 "},{"name":"pizza signature pepperoni","price":"9.79 "},{"name":"meat supreme signature pizza","price":"14.29 "},{"name":"grilled veggies and goat cheese signature pizza","price":"14.29 "},{"name":"pizza amore","price":"15.29 "},{"name":"sweet chilli thai chicken","price":"15.29 "},{"name":"spicy bbq chicken signature pizza","price":"14.79 "},{"name":"bacon double cheeseburger signature pizza","price":"12.29 "},{"name":"cheese panzerotti","price":"6.79 "},{"name":"pepperoni panzerotti","price":"6.79 "},{"name":"cheese calzone","price":"6.79 "},{"name":"poutine","price":"4.49 "},{"name":"big box fries","price":"4.99 "},{"name":"big box onion rings","price":"4.99 "},{"name":"coke classic","price":"2.29 "},{"name":"diet coke","price":"2.29 "},{"name":"sprite","price":"2.29 "},{"name":"nestea","price":"2.29 "},{"name":"bottled water","price":"1.99 "}],"openingtime":"11 AM","closingtime":"12:45 AM","nearbyresturantsidifordered":[{"id":1},{"id":2},{"id":4},{"id":5},{"id":6},{"id":7}]}');
    jsonRestaurants.add('{"image":"https://image.shutterstock.com/image-photo/healthy-vegetable-salad-fresh-tomato-260nw-1008313948.jpg","id":4,"name":"SALADIOM RESTAURANT","address":"1635 Saint Denis St, Montreal, Quebec H2L 1Y2, Canada","location":"H2L 1Y2","fooditems":[{"name":"shiraz salads","price":"11.63 "},{"name":"rising sun salad","price":"9.99 "},{"name":"caesar salad","price":"10.9 "},{"name":"saladiom","price":"11.83 "},{"name":"rainbow salad","price":"10.9 "},{"name":"taco","price":"10.9 "},{"name":"tonic","price":"11.83 "},{"name":"ocean","price":"12.73 "},{"name":"chilli soup","price":"4.99 "},{"name":"vegetable soup","price":"4.99 "},{"name":"chicken mushroom soup","price":"6.37 "},{"name":"sweet crepe","price":"5.91 "},{"name":"bottled water","price":"1.73 "},{"name":"salt crepe","price":"4.99 "}],"openingtime":"4 PM","closingtime":"10:30 PM","nearbyresturantsidifordered":[{"id":1},{"id":2},{"id":3},{"id":5},{"id":6},{"id":7}]}');
    jsonRestaurants.add('{"image":"https://image.shutterstock.com/image-photo/beef-chicken-shawarma-sandwich-plate-260nw-1764847952.jpg","id":5,"name":"RESTAURANT BASHA","address":"3766 St Laurent Blvd, Montreal, Quebec H2W 1X6, Canada","location":"H2W 1X6","fooditems":[{"name":"falafel trio","price":"8.99 "},{"name":"shish taouk shawarma","price":"9.99 "},{"name":"kafta","price":"9.99 "},{"name":"poulet trio","price":"11.99 "},{"name":"filet mignon","price":"11.99 "},{"name":"salade","price":"2 "},{"name":"taboule salade","price":"4.99 "},{"name":"greek salad","price":"4.99 "},{"name":"fattouche salad","price":"4.99 "},{"name":"fries","price":"4.99 "},{"name":"chicken wings","price":"4.99 "},{"name":"moussakka","price":"4.99 "},{"name":"cheese rolls","price":"4.99 "}],"openingtime":"11:30 AM","closingtime":"11 PM","nearbyresturantsidifordered":[{"id":1},{"id":2},{"id":3},{"id":4},{"id":6},{"id":7}]}');
    jsonRestaurants.add('{"image":"https://image.shutterstock.com/image-photo/four-sandwiches-on-board-260nw-365116274.jpg","id":6,"name":"ALLO MON COCO","address":"70 Rue Sainte-Catherine Est, Montreal, Quebec H2X 1K6","location":"H2X 1K6","fooditems":[{"name":"avocado toast","price":"16.75 "},{"name":"regular coco omlet","price":"10.95 "},{"name":"western coco omlet","price":"14.95 "},{"name":"bacon coco omlet","price":"13.95 "},{"name":"ham coco omlet","price":"13.95 "},{"name":"beef salami and onion coco omlet","price":"16.5 "},{"name":"phily coco omlet","price":"16.95 "},{"name":"sunshine","price":"15.5 "},{"name":"bon matin","price":"15.5 "},{"name":"good morning","price":"15.5 "},{"name":"breakfast poutine","price":"15.5 "},{"name":"american steak n eggs","price":"21.95 "},{"name":"oreo coco waffle","price":"16.95 "},{"name":"allo mon coco omlet","price":"16.95 "},{"name":"smoked salmon and onion coco omlet","price":"19.95 "},{"name":"charly special","price":"15.95 "},{"name":"coco casserole","price":"16.5 "},{"name":"western casserole","price":"15.95 "},{"name":"cofee","price":"1.95 "},{"name":"orange juice","price":"3.5 "},{"name":"smoothie ","price":"4.5 "}],"openingtime":"6 AM","closingtime":"3:30 PM","nearbyresturantsidifordered":[{"id":1},{"id":2}]}');
    jsonRestaurants.add('{"image":"https://image.shutterstock.com/image-photo/traditional-seafood-paella-fry-pan-260nw-572640955.jpg","id":7,"name":"MONTREAL PAELLA","address":"3686B St Laurent Blvd, Montreal, Quebec H2X 2V4, Canada","location":"H2X 2V4","fooditems":[{"name":"seafood paella","price":"17.95 "},{"name":"paella valenciana","price":"18.95 "},{"name":"patatas bravas","price":"7 "},{"name":"garlic shrimps","price":"18 "},{"name":"chicken paella","price":"14.95 "},{"name":"black rice","price":"19.95 "},{"name":"del senyoret","price":"19.95 "},{"name":"beef stew","price":"16 "},{"name":"grilled octopus","price":"32 "},{"name":"iberian ham sandwich","price":"18 "},{"name":"chicken croquettes","price":"9 "},{"name":"iberian ham croquettes","price":"31.5 "},{"name":"flan","price":"6 "},{"name":"eska water","price":"2 "},{"name":"grape juice","price":"4.5 "},{"name":"white raisin","price":"4.5 "},{"name":"apple juice","price":"4.5 "},{"name":"white chocolate rice pudding","price":"6 "},{"name":"mixta","price":"23 "}],"openingtime":"12 PM","closingtime":"9 PM","nearbyresturantsidifordered":[{"id":1},{"id":2},{"id":3},{"id":4},{"id":5},{"id":6}]}');
    jsonRestaurants.add('{"image":"https://image.shutterstock.com/image-photo/chicken-kabsa-homemade-arabian-biryani-260nw-1048188118.jpg","id":8,"name":"LAKSHANA CHETTINADU RESTAURANT","address":"5623 COTE DES NIEGES RD","location":"H3T 1Y8","fooditems":[{"name":"veg samosa","price":"3.49 "},{"name":"sambar idly","price":"3.49 "},{"name":"sambar vada","price":"3.49 "},{"name":"medhu vada","price":"3.49 "},{"name":"chettinad chicken 65","price":"11.99 "},{"name":"chicken pakora","price":"10.99 "},{"name":"fish pakora","price":"10.99 "},{"name":"chettinad chicken soup","price":"3.99 "},{"name":"paneer tikka","price":"11.99 "},{"name":"tandoori chicken","price":"11.99 "},{"name":"tandoori shrimp","price":"12.99 "},{"name":"chicken tikka","price":"12.99 "},{"name":"butter chicken","price":"12.99 "},{"name":"chettinad chicken curry","price":"12.99 "},{"name":"kadai chicken","price":"13.99 "},{"name":"chicken tikka masala","price":"13.99 "},{"name":"chicken vindalo","price":"13.99 "},{"name":"chettinad lamb curry","price":"13.99 "},{"name":"lamb vindaloo","price":"14.99 "},{"name":"plain dosa","price":"8.99 "},{"name":"podi dosa ","price":"9.99 "},{"name":"garlic kara dosa","price":"9.99 "},{"name":"chicken kothu parotta","price":"12.99 "},{"name":"chettinad lamb biriyani","price":"13.99 "},{"name":"chicken biriyani","price":"12.99 "},{"name":"chicken 65 biriyani","price":"13.99 "},{"name":"poori masala ","price":"9.99 "},{"name":"plain utthappam","price":"8.99 "},{"name":"onion utthappam","price":"9.99 "},{"name":"rava kesari","price":"2.99 "},{"name":"gulab jamun","price":"2.99 "},{"name":"rasmalai","price":"2.99 "},{"name":"7 up or coke or ginger ale","price":"1.75 "}],"openingtime":"11:30 AM","closingtime":"9:45 PM","nearbyresturantsidifordered":[{"id":9},{"id":10},{"id":11},{"id":12},{"id":13},{"id":14},{"id":15},{"id":16},{"id":17}]}');
    jsonRestaurants.add('{"image":"https://image.shutterstock.com/image-photo/noodles-steam-smoke-bowl-on-260nw-1149527465.jpg","id":9,"name":"POKAI","address":"5147A COTE DES NIEGES RD","location":"H3T 1X9","fooditems":[{"name":"salmon poke","price":"14 "},{"name":"tuna poke","price":"14 "},{"name":"unagi poke","price":"14 "},{"name":"shrimp poke","price":"14 "},{"name":"mixed salad","price":"12 "},{"name":"spicey wakame salad","price":"12 "},{"name":"banh mi","price":"5.5 "},{"name":"spring rolls","price":"6.5 "},{"name":"coca cola","price":"1.5 "},{"name":"pepsi","price":"1.5 "},{"name":"bubly","price":"1.5 "},{"name":"canada dry","price":"1.5 "},{"name":"nestea","price":"1.5 "},{"name":"apple juice","price":"1.5 "},{"name":"orange juice","price":"1.5 "},{"name":" grilled chicken poke","price":"14 "}],"openingtime":"11:00 AM","closingtime":"7:00 PM","nearbyresturantsidifordered":[{"id":8},{"id":10},{"id":11},{"id":12},{"id":13},{"id":14},{"id":15},{"id":16},{"id":17}]}');
    jsonRestaurants.add('{"image":"https://image.shutterstock.com/image-photo/doner-meat-french-fries-260nw-1479089261.jpg","id":10,"name":"BOUSTAN","address":"5700 COTE DES NIEGES RD","location":"H3T 2A8","fooditems":[{"name":"Ass shawarma poulet","price":"13.25 "},{"name":"Ass shawarma boeuf","price":"13.49 "},{"name":"Ass shawarma mixte","price":"13.95 "},{"name":"assiette saj poulet","price":"3.49 "},{"name":"assiette saj boeuf","price":"11.99 "},{"name":"Assiette sante","price":"14.5 "},{"name":"Ass kafta kebab","price":"14.25 "},{"name":"assiette mixte saf poulet et boeuf","price":"13.5 "},{"name":"pita poulet shawarma","price":"6.45 "},{"name":"pita boeuf shawrama","price":"6.45 "},{"name":"pita mixed shawarma","price":"6.95 "},{"name":"pita pain saj poulet","price":"7.5 "},{"name":"pita pain saj boeuf","price":"7.5 "},{"name":"pita kafta kebab","price":"6.95 "},{"name":"pita creation l ultime","price":"6.75 "},{"name":"pita vegetarian","price":"5.45 "},{"name":"trio poulet shawarma","price":"10.45 "},{"name":"trio boeuf shawarma","price":"10.75 "},{"name":"trio mixte shawarma","price":"10.95 "},{"name":"trio pain saj poulet","price":"11.25 "},{"name":"trio pain saj boeuf ","price":"11.25 "},{"name":"trio pain saj mixte","price":"11.5 "},{"name":"trio kafta","price":"10.95 "},{"name":"trio falafel","price":"8.95 "},{"name":"trio vegetarian","price":"9.45 "},{"name":"pita vegan","price":"7.95 "},{"name":"vegan trio","price":"11.45 "},{"name":"Ass.vegan","price":"14.99 "},{"name":"baklava","price":"2.25 "},{"name":"petite boite baklava","price":"5 "},{"name":"grande boite baklava","price":"6.5 "},{"name":"bubbly strawberry","price":"2 "},{"name":"mountain dew or ginger ale","price":"2 "}],"openingtime":"11:00 AM","closingtime":"12:00 AM","nearbyresturantsidifordered":[{"id":8},{"id":9},{"id":11},{"id":12},{"id":13},{"id":14},{"id":15},{"id":16},{"id":17}]}');
jsonRestaurants.add('{"image":"https://image.shutterstock.com/image-photo/baked-chicken-wings-sesame-seeds-260nw-703774375.jpg","id":11,"name":"PIRI PIRI","address":"5480 COTE DES NIEGES RD","location":"H3T 1Y7","fooditems":[{"name":"ribs appetizer","price":"5.95 "},{"name":"chorizo appetizer","price":"4.25 "},{"name":"scallops appetizer","price":"3 "},{"name":"chicken supreme piri bowl","price":"14.5 "},{"name":"chicken escalope piri bowl","price":"13.5 "},{"name":"vegetable piri bowl","price":"11.5 "},{"name":"large chicken salad","price":"13.25 "},{"name":"large caesar salad","price":"12.75 "},{"name":"roasted whole chicken","price":"16.5 "},{"name":"2 chicken skewers","price":"15.7 "},{"name":"2 chicken legs","price":"14.7 "},{"name":"chicken wings","price":"13.25 "},{"name":"hunter s plate","price":"17.95 "},{"name":"carnivourous plate","price":"17.5 "},{"name":"portugese s plate","price":"16.5 "},{"name":"roasted pork sandwich","price":"8.25 "},{"name":"marinated chicken sandwich","price":"7.75 "},{"name":"bifana sandwich","price":"7.75 "},{"name":"chorizo sandwich","price":"7.75 "},{"name":"roast pork sandwich plate","price":"13.25 "},{"name":"marinated chicken sandwich plate","price":"12.75 "},{"name":"deluxe roasted pork","price":"9.45 "},{"name":"deluxe marinated chicken","price":"8.95 "},{"name":"deluxe chorizo","price":"8.95 "},{"name":"full rack of ribs plate","price":"21.45 "},{"name":"half ribs","price":"15.95 "},{"name":"pickled pork cutlets","price":"14.5 "},{"name":"roasted pork","price":"13.95 "},{"name":"regular supreme poutine","price":"12.75 "},{"name":"regular chicken poutine","price":"11.5 "},{"name":"regular poutine piri piri","price":"11.5 "},{"name":"chicken wings","price":"6.95 "},{"name":"soft drink","price":"2 "}],"openingtime":"12 PM","closingtime":"9 PM","nearbyresturantsidifordered":[{"id":9},{"id":10},{"id":8},{"id":12},{"id":13},{"id":14},{"id":15},{"id":16},{"id":17}]}');
jsonRestaurants.add('{"image":"https://image.shutterstock.com/image-photo/01-january-2020-medan-city-260nw-1604999869.jpg","id":12,"name":"A&W CANADA","address":"5120 QUEEN MARY ROAD","location":"H3W 1X2","fooditems":[{"name":"teen burger combo","price":"10.78 "},{"name":"double teen burger combo","price":"12.38 "},{"name":"mozza burger combo","price":"10.78 "},{"name":"double mozza burger combo","price":"12.38 "},{"name":"cheddar bacon uncle combo","price":"12.78 "},{"name":"mama burger combo","price":"9.28 "},{"name":"papa burger combo","price":"10.88 "},{"name":"grandpa burger combo","price":"12.48 "},{"name":"buddy burger combo","price":"6.08 "},{"name":"beyond meat burger combo","price":"11.08 "},{"name":"chubby chicken and burger combo","price":"10.78 "},{"name":"blt chicken burger","price":"11.58 "},{"name":"3 chicken strips combo","price":"10.98 "},{"name":"5 chicken strips combo","price":"13.18 "},{"name":"chicken buddy burger","price":"6.58 "},{"name":"chicken wrap combo","price":"6.68 "},{"name":"2 chicken wraps combo","price":"8.88 "},{"name":"english muffin bacon and egger combo","price":"6.88 "},{"name":"bacon and egger combo","price":"6.88 "},{"name":"engish muffin sausage and egger combo","price":"6.88 "},{"name":"teen burger","price":"6.89 "},{"name":"double teen burger","price":"8.49 "},{"name":"mozza burger","price":"6.89 "},{"name":"double mozza burger","price":"8.49 "},{"name":"mama burger","price":"5.39 "},{"name":"papa burger","price":"6.99 "},{"name":"buddy burger","price":"2.19 "},{"name":"3 chicken strips","price":"3.09 "},{"name":"thick cut fries","price":"2.89 "},{"name":"poutine","price":"4.89 "},{"name":"hashbrown","price":"1.89 "},{"name":"sweet potato fries","price":"4.09 "},{"name":"diet coke/iced tea/sprite","price":"2.19 "}],"openingtime":"11:00 AM","closingtime":"11:00 PM","nearbyresturantsidifordered":[{"id":9},{"id":10},{"id":11},{"id":8},{"id":13},{"id":14},{"id":15},{"id":16},{"id":17}]}');
jsonRestaurants.add('{"image":"https://image.shutterstock.com/image-photo/mutton-biriyani-on-black-dish-260nw-1720502545.jpg","id":13,"name":"HYDERABADI ADDA","address":"4976 QUEEN MARY ROAD","location":"H3W 1X2","fooditems":[{"name":"chicken 65","price":"11.99 "},{"name":"gobi 65","price":"10.99 "},{"name":"paneer 65","price":"10.99 "},{"name":"baby corn 65","price":"10.99 "},{"name":"veg hakka noodles","price":"9.99 "},{"name":"chicken hakka nooodles","price":"10.99 "},{"name":"egg hakka noodles","price":"9.99 "},{"name":"veg schezwan noodles","price":"7.99 "},{"name":"egg schezwan fried rice","price":"8.5 "},{"name":"chicken schezwan fried rice","price":"10.99 "},{"name":"chicken rice plate","price":"25.99 "},{"name":"lamb rice plate","price":"27.99 "},{"name":"fish rice plate","price":"27.99 "},{"name":"hyderbadi paneer masala curry","price":"10.99 "},{"name":"paneer butter masala","price":"10.99 "},{"name":"butter chicken curry","price":"11.99 "},{"name":"hyderbadi dum ka chicken curry","price":"11.99 "},{"name":"hyderbadi chicken dum biriyani","price":"11.99 "},{"name":"veggie dum biriyani","price":"10.99 "},{"name":"lamb dum biriyani","price":"12.99 "},{"name":"hyderbadi chicken bucket dum biriyani","price":"29.99 "},{"name":"lemon juice","price":"3.99 "},{"name":"mango juice","price":"3.99 "},{"name":"mango lassi","price":"3.99 "},{"name":"water bottle","price":"1.25 "},{"name":"gulab juman","price":"2.99 "}],"openingtime":"5:00 PM","closingtime":"12:30 AM","nearbyresturantsidifordered":[{"id":9},{"id":10},{"id":11},{"id":12},{"id":8},{"id":14},{"id":15},{"id":16},{"id":17}]}');
jsonRestaurants.add('{"image":"https://image.shutterstock.com/image-photo/hawaiian-salmon-tuna-shrimp-poke-260nw-1177552387.jpg","id":14,"name":"OLU OLU POKE","address":"4986 QUEEN MARY ROAD","location":"H3W 1X2","fooditems":[{"name":"miso soup","price":"2.95 "},{"name":"shrimp miso soup","price":"4.95 "},{"name":"seafood miso soup","price":"5.5 "},{"name":"simple love","price":"13.95 "},{"name":"ahi-limu","price":"13.95 "},{"name":"el classico","price":"13.95 "},{"name":"unagi bowl","price":"15.95 "},{"name":"amelika bowl","price":"14.95 "},{"name":"shrimpo hunter","price":"14.95 "},{"name":"tandoori chicken","price":"11.99 "},{"name":"oppa korea","price":"14.95 "},{"name":"mamba","price":"14.95 "},{"name":"smiling buddha","price":"13.5 "},{"name":"house salad","price":"8.5 "},{"name":"tropical rythms pineapple guava","price":"3.5 "},{"name":"tropical rythms pineapple ginger","price":"3.5 "},{"name":"tropical rythms mango carrot","price":"3.5 "},{"name":"tropical rythms fruit punch","price":"3.5 "},{"name":"ginger ale","price":"2 "},{"name":"diet coke","price":"2 "},{"name":"iced tea","price":"2 "},{"name":"cream soda","price":"2.5 "},{"name":"carbonated water","price":"2.5 "},{"name":"homemade hot sauce","price":"1.5 "},{"name":"creamy ponzu","price":"1.5 "},{"name":"olu special sauce","price":"1.5 "}],"openingtime":"11:00 AM","closingtime":"10:00 PM","nearbyresturantsidifordered":[{"id":9},{"id":10},{"id":11},{"id":12},{"id":13},{"id":8},{"id":15},{"id":16}]}');
jsonRestaurants.add('{"image":"https://image.shutterstock.com/image-photo/beef-steaks-on-grill-flames-260nw-413329057.jpg","id":15,"name":"GRILLADES DA SILVA","address":"5334 QUEEN MARY ROAD","location":"H3X 2K9","fooditems":[{"name":"house salad","price":"8 "},{"name":"tuna steak salad","price":"22.95 "},{"name":"fresh salmon salad","price":"25 "},{"name":"chicken salad","price":"16.9 "},{"name":"1/4 chicken leg combo","price":"12.35 "},{"name":"1/4 chicken breast combo","price":"13.95 "},{"name":"family combo","price":"40 "},{"name":"chicken sandwich","price":"12.5 "},{"name":"tuna steak sandwich","price":"17.55 "},{"name":"fresh salmon sandwich","price":"19.5 "},{"name":"beef burger","price":"14.30 "},{"name":"chicken mains","price":"8.45 "},{"name":"fries","price":"7.25 "},{"name":"hot sauce","price":"2.5 "},{"name":"1/2 chicken","price":"13.55 "},{"name":"sardines","price":"15.55 "},{"name":"soft drink","price":"2.7 "},{"name":"iced tea","price":"2.7 "},{"name":"juice","price":"3.4 "},{"name":"natural fruit nectar","price":"3 "},{"name":"canada dry","price":"2.10 "},{"name":"coke","price":"2.10 "}],"openingtime":"3:00 PM","closingtime":"7:00 PM","nearbyresturantsidifordered":[{"id":9},{"id":10},{"id":11},{"id":12},{"id":13},{"id":14},{"id":8},{"id":16},{"id":17}]}');
jsonRestaurants.add('{"image":"https://image.shutterstock.com/image-photo/super-delicious-poutine-french-fries-260nw-1686194737.jpg","id":16,"name":"POUTINEVILLE","address":"5405 QUEEN MARY ROAD","location":"H3X 1V1","fooditems":[{"name":"poutineville combo","price":"20 "},{"name":"fried calamari","price":"13.5 "},{"name":"chicken wings","price":"11 "},{"name":"breaded dill pickles","price":"9 "},{"name":"mac and cheese wedges","price":"8.5 "},{"name":"greek salad","price":"10.75 "},{"name":"caesar salad","price":"9.5 "},{"name":"house salad","price":"9.5 "},{"name":"smoked meat deli melt","price":"16.75 "},{"name":"classic grilled cheese","price":"12 "},{"name":"sloppy joe grilled cheese","price":"16.75 "},{"name":"vegetarian grilled cheese","price":"15.75 "},{"name":"bacon blue burger","price":"12 "},{"name":"deluxe burger","price":"12 "},{"name":"cheeseburger","price":"11 "},{"name":"piquante burger","price":"11 "},{"name":"crispy chicken burger","price":"11.75 "},{"name":"vegetarian burger","price":"11.75 "},{"name":"grilled chicken burger","price":"11.75 "},{"name":"classic burger","price":"9 "},{"name":"all dressed submarine","price":"16 "},{"name":"chicken submarine","price":"2.10 "},{"name":"bbq extreme hot dog","price":"10.75 "},{"name":"base poutine","price":"9.5 "},{"name":"filet mignon poutine","price":"25.25 "},{"name":"poutine phily steak","price":"2.10 "}],"openingtime":"11:00 AM","closingtime":"10:00 PM","nearbyresturantsidifordered":[{"id":9},{"id":10},{"id":11},{"id":12},{"id":13},{"id":14},{"id":8},{"id":15},{"id":17}]}');
jsonRestaurants.add('{"image":"https://image.shutterstock.com/image-photo/four-sandwiches-on-board-260nw-365116274.jpg","id":17,"name":"ALLO MON COCO","address":"70 Rue Sainte-Catherine Est, Montreal, Quebec H2X 1K6","location":"H2X 1K6","fooditems":[{"name":"avocado toast","price":"16.75 "},{"name":"regular coco omlet","price":"10.95 "},{"name":"western coco omlet","price":"14.95 "},{"name":"bacon coco omlet","price":"13.95 "},{"name":"ham coco omlet","price":"13.95 "},{"name":"beef salami and onion coco omlet","price":"16.5 "},{"name":"phily coco omlet","price":"16.95 "},{"name":"sunshine","price":"15.5 "},{"name":"bon matin","price":"15.5 "},{"name":"good morning","price":"15.5 "},{"name":"breakfast poutine","price":"15.5 "},{"name":"american steak n eggs","price":"21.95 "},{"name":"oreo coco waffle","price":"16.95 "},{"name":"allo mon coco omlet","price":"16.95 "},{"name":"smoked salmon and onion coco omlet","price":"19.95 "},{"name":"charly special","price":"15.95 "},{"name":"coco casserole","price":"16.5 "},{"name":"western casserole","price":"15.95 "},{"name":"cofee","price":"1.95 "},{"name":"orange juice","price":"3.5 "},{"name":"smoothie ","price":"4.5 "}],"openingtime":"6 AM","closingtime":"3:30 PM","nearbyresturantsidifordered":[{"id":9},{"id":10},{"id":11},{"id":12},{"id":13},{"id":14},{"id":8},{"id":15}]}');
jsonRestaurants.add('{"image":"https://image.shutterstock.com/image-photo/ethiopian-tibse-injera-260nw-739906927.jpg","id":18,"name":"restaurant queen sheba","address":"4525 Park Ave, Montreal, Quebec H2V 4E4, Canada","location":"H2V 4E4","fooditems":[{"name":"azifa","price":"6 "},{"name":"boutitch a","price":"6 "},{"name":"timatime selata","price":"6 "},{"name":"doro tibs","price":"18 "},{"name":"sega tibs","price":"17 "},{"name":"chacha tibs","price":"18 "},{"name":"dulete kitfo","price":"17 "},{"name":"atakeit wat","price":"14 "},{"name":"gommen","price":"14 "},{"name":"fosolia","price":"14 "},{"name":"shiro wat","price":"14 "},{"name":"assa goulash","price":"175 "},{"name":"key wat","price":"15 "},{"name":"alitch a wat","price":"15 "},{"name":"minchet abish","price":"14 "},{"name":"doro wat","price":"16 "}],"openingtime":"3:00 PM","closingtime":"7:00 PM","nearbyresturantsidifordered":[{"id":19},{"id":20},{"id":21},{"id":22}]}');
jsonRestaurants.add('{"image":"https://image.shutterstock.com/image-photo/fried-salmon-steak-potatoes-vegetables-260nw-1708527529.jpg","id":19,"name":"restaurant zante","address":"1112 Sherbrooke St W, Montreal, Quebec H3A 1G9, Canada","location":"H3A 1G9","fooditems":[{"name":"Pieuvres grilles","price":"34 "},{"name":"Gâteau de crabe rôti","price":"22 "},{"name":"Saganaki de crevettes (4 mcx)","price":"26 "},{"name":"Légumes grillés","price":"22 "},{"name":"Salade grecque traditionnelle","price":"20 "},{"name":"Psilokomeni","price":"14 "},{"name":"Salade Zante","price":"14 "},{"name":"Saumon biologique grillé","price":"26"},{"name":"Crevettes géantes grillées (3 mcx)","price":"40 "},{"name":"Spaghetti","price":"22 "},{"name":"Poitrine de poulet grillée Zante","price":"24 "},{"name":"Steak de boeuf grillé (USDA)","price":"62 "},{"name":"Pita et tzatziki","price":"12 "},{"name":"Gigantes","price":"9 "},{"name":"Frites","price":"5 "},{"name":"Assiette de légumes verts","price":"8 "}],"openingtime":"5:30 PM","closingtime":"11:00 PM","nearbyresturantsidifordered":[{"id":18},{"id":20},{"id":21},{"id":22}]}');
jsonRestaurants.add('{"image":"https://image.shutterstock.com/image-photo/japanese-sushi-food-maki-ands-260nw-1470615731.jpg","id":20,"name":"saint sushi pleateau","address":"424 Duluth Ave E, Montreal, Quebec H2L 1A3, Canada","location":"H2L 1A3","fooditems":[{"name":"tasting menu","price":"44.55 "},{"name":"bonnie","price":"40.43 "},{"name":"clyde","price":"46.75 "},{"name":"miso soup","price":"5.23 "},{"name":"shrimp tempura","price":"11.55 "},{"name":"wakame","price":"4.68 "},{"name":"rice and sesame","price":"3.58 "},{"name":"kappa maki","price":"5.78 "},{"name":"avocado maki","price":"6.05 "},{"name":"syake maki","price":"7.7 "},{"name":"tekka maki","price":"9.35 "},{"name":"michael jackson maki","price":"19.53 "},{"name":"beatles maki","price":"18.98 "},{"name":"bob marley maki","price":"20.9 "},{"name":"madonna maki","price":"15.13 "},{"name":"marvin gaye maki","price":"15.68 "},{"name":"tupac maki","price":"15.13 "},{"name":"coca cola","price":"3.3 "},{"name":"coca cola diet","price":"3.3 "}],"openingtime":"4:30 PM","closingtime":"9:00 PM","nearbyresturantsidifordered":[{"id":18},{"id":19},{"id":21},{"id":22}]}');
jsonRestaurants.add('{"image":"https://image.shutterstock.com/image-photo/grilled-chicken-fillet-fresh-vegetable-260nw-1771466018.jpg","id":21,"name":"omnivore","address":"4306 St Laurent Blvd, Montreal, Quebec H2W 1Z3, Canada","location":"H2W 1Z3","fooditems":[{"name":"roma sandwich","price":"8.5 "},{"name":"beirut sandwich","price":"8.5 "},{"name":"thai sandwich","price":"8.5 "},{"name":"inca sandwich","price":"8.5 "},{"name":"djaj sandwich","price":"8.5 "},{"name":"samak sandwich","price":"8.5 "},{"name":"arez sandwich","price":"8.5 "},{"name":"khodra sandwich","price":"7.5 "},{"name":"flexivore","price":"21 "},{"name":"omnivore","price":"16 "},{"name":"herbivore","price":"14 "},{"name":"fattoush","price":"6 "},{"name":"orzo","price":"6 "},{"name":"moussaka","price":"6 "},{"name":"hummus","price":"6 "},{"name":"baba ghanoush","price":"7 "},{"name":"baklava","price":"3 "},{"name":"maamoul","price":"3 "},{"name":"namoura","price":"4.5 "}],"openingtime":"11:00 AM","closingtime":"8:45 PM","nearbyresturantsidifordered":[{"id":18},{"id":19},{"id":20},{"id":22}]}');
jsonRestaurants.add('{"image":"https://image.shutterstock.com/image-photo/01-january-2020-medan-city-260nw-1604999869.jpg","id":22,"name":"a&w","address":"4505 Avenue Du Parc, Montréal, QC","location":"H2V 4E4","fooditems":[{"name":"teen burger combo","price":"10.78 "},{"name":"double teen burger combo","price":"12.38 "},{"name":"mozza burger combo","price":"10.78 "},{"name":"double mozza burger combo","price":"12.38 "},{"name":"cheddar bacon uncle combo","price":"12.78 "},{"name":"mama burger combo","price":"9.28 "},{"name":"papa burger combo","price":"10.88 "},{"name":"grandpa burger combo","price":"12.48 "},{"name":"buddy burger combo","price":"6.08 "},{"name":"beyond meat burger combo","price":"11.08 "},{"name":"chubby chicken and burger combo","price":"10.78 "},{"name":"blt chicken burger","price":"11.58 "},{"name":"3 chicken strips combo","price":"10.98 "},{"name":"5 chicken strips combo","price":"13.18 "},{"name":"chicken buddy burger","price":"6.58 "},{"name":"chicken wrap combo","price":"6.68 "},{"name":"2 chicken wraps combo","price":"8.88 "},{"name":"english muffin bacon and egger combo","price":"6.88 "},{"name":"bacon and egger combo","price":"6.88 "},{"name":"engish muffin sausage and egger combo","price":"6.88 "},{"name":"teen burger","price":"6.89 "},{"name":"double teen burger","price":"8.49 "},{"name":"mozza burger","price":"6.89 "},{"name":"double mozza burger","price":"8.49 "},{"name":"mama burger","price":"5.39 "},{"name":"papa burger","price":"6.99 "},{"name":"buddy burger","price":"2.19 "},{"name":"3 chicken strips","price":"3.09 "},{"name":"thick cut fries","price":"2.89 "},{"name":"poutine","price":"4.89 "},{"name":"hashbrown","price":"1.89 "},{"name":"sweet potato fries","price":"4.09 "},{"name":"diet coke/iced tea/sprite","price":"2.19 "}],"openingtime":"11:00 AM","closingtime":"11:00 PM","nearbyresturantsidifordered":[{"id":18},{"id":19},{"id":20},{"id":21}]}');
    for(var i=0;i<jsonRestaurants.length;i++) {
      entity = Restaurants.fromJson(jsonDecode(jsonRestaurants[i]));
      parsedRestaurants.add(entity);
    }
  }

  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        drawer: Drawer(
          child: ListView(
            padding: EdgeInsets.zero,
            children: <Widget>[
              DrawerHeader(
                child: Text(
                  'FOOD-OH',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 36.0,
                  ),
                ),
                decoration: BoxDecoration(
                  color: kSecondaryColor,
                ),
              ),
              ListTile(
                leading: IconButton(
                  icon: Icon(
                    Icons.home_outlined,
                    color: Colors.black,
                  ),
                  onPressed: () {
                    // do something

                  },
                ),
                title: Text(
                  'Home',
                  style: TextStyle(
                    fontSize: 24.0,
                  ),
                ),
                onTap: () {
                  // this.setCurrentPage('Dish Screen');
                  this.setCurrentPage('Restaurant Screen');
                },
              ),
              ListTile(
                leading: IconButton(
                  icon: Icon(
                    Icons.add_shopping_cart,
                    color: Colors.black,
                  ),
                  onPressed: () {
                    // do something
                  },
                ),
                title: Text(
                  'Orders',
                  style: TextStyle(
                    fontSize: 24.0,
                  ),
                ),
                onTap: () {
                  Navigator.pop(context);
                },
              ),
              ListTile(
                leading: IconButton(
                  icon: Icon(
                    Icons.login_outlined,
                    color: Colors.black,
                  ),
                  onPressed: () {
                    // do something
                  },
                ),
                title: Text(
                  'Logout',
                  style: TextStyle(
                    fontSize: 24.0,
                  ),
                ),
                onTap: () {
                  Navigator.pop(context);
                },
              ),
            ],
          ),
        ),
        appBar: AppBar(
          title: Text(widget.title),
          backgroundColor: kSecondaryColor,
          actions: <Widget>[
            Padding(
              padding: const EdgeInsets.only(right: 16.0, top: 8.0),
              child: GestureDetector(
                child: Stack(
                  alignment: Alignment.topCenter,
                  children: <Widget>[
                    Icon(
                      Icons.shopping_cart,
                      size: 36.0,
                    ),
                    if (_cartList.length > 0)
                      Padding(
                        padding: const EdgeInsets.only(left: 2.0),
                        child: CircleAvatar(
                          radius: 8.0,
                          backgroundColor: Colors.red,
                          foregroundColor: Colors.white,
                          child: Text(
                            _cartList.length.toString(),
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 12.0,
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
                onTap: () {
                  if (_cartList.isNotEmpty)
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (context) => Cart(_cartList),
                      ),
                    );
                },
              ),
            )
          ],
        ),
        // body: _buildGridView(),
        body: currentPage == 'Restaurant Screen' ? _buildRestaurantsGrid() : _buildDishScreen()
      ),
    );
  }


  // ListView _buildListView() {
  //   return ListView.builder(
  //     itemCount: _dishes.length,
  //     itemBuilder: (context, index) {
  //       var item = _dishes[index];
  //       return Padding(
  //         padding: const EdgeInsets.symmetric(
  //           horizontal: 8.0,
  //           vertical: 2.0,
  //         ),
  //         child: Card(
  //           elevation: 4.0,
  //           child: ListTile(
  //             leading: Icon(
  //               item.icon,
  //               color: item.color,
  //             ),
  //             title: Text(item.name),
  //             trailing: GestureDetector(
  //               child: (!_cartList.contains(item))
  //                   ? Icon(
  //                       Icons.add_circle,
  //                       color: Colors.green,
  //                     )
  //                   : Icon(
  //                       Icons.remove_circle,
  //                       color: Colors.red,
  //                     ),
  //               onTap: () {
  //                 setState(() {
  //                   if (!_cartList.contains(item))
  //                     _cartList.add(item);
  //                   else
  //                     _cartList.remove(item);
  //                 });
  //               },
  //             ),
  //           ),
  //         ),
  //       );
  //     },
  //   );
  // }

  GridView _buildDishScreen() {
    List<FoodItems> lstFoodItems = this.parsedRestaurants.where((element) => element.id == currentId).first.fooditems.toList();
    return GridView.builder(
 padding: const EdgeInsets.all(4.0),
        gridDelegate:
            SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
        itemCount: lstFoodItems.length,
        itemBuilder: (context, index) {
          var item = lstFoodItems[index];
          var restaurant = parsedRestaurants[currentId-1];
          return Card(
              elevation: 4.0,
              child: Stack(
                fit: StackFit.loose,
                alignment: Alignment.center,
                children: <Widget>[
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Icon(
                        Icons.food_bank_outlined,
                        color: (_cartList.contains(item))
                            ? Colors.grey
                            : Colors.green,
                        size: 100.0,
                      ),
                      
                      Text(
                        item.name,
                        textAlign: TextAlign.center,
                        style: Theme.of(context).textTheme.subhead,
                      ),
                      Text(
                        item.price + 'CAD',
                        textAlign: TextAlign.center,
                        style: Theme.of(context).textTheme.bodyText1,
                      ),
                      Text(
                        restaurant.name,
                        textAlign: TextAlign.center,
                        style: Theme.of(context).textTheme.bodyText1,
                      ),
                    ],
                  ),
                  Padding(
                    padding: const EdgeInsets.only(
                      right: 8.0,
                      bottom: 8.0,
                    ),
                    child: Align(
                      alignment: Alignment.bottomRight,
                      child: GestureDetector(
                        child: (!_cartList.contains(item))
                            ? Icon(
                                Icons.add_circle,
                                color: Colors.green,
                              )
                            : Icon(
                                Icons.remove_circle,
                                color: Colors.red,
                              ),
                        onTap: () {
                          setState(() {
                            if(_cartList.length > 0) {
                              var firstItem = _cartList[0];
                              //this.currentId = currentId;
                              // check if the adding item belongs to the same or the restaurants nearby
                              // if true, allow to add
                              // else -> show list of restaurants nearby and tell the user that only from there they can order
                              if(!(this.checkIfNearbyRestaurant(item) || this.checkIfSameRestaurant(item))) {
                                this.showAlertDialog(context, 'RESTAURANT FAR AWAY, LOOK FOR ANOTHER RESTAURANT NEARBY !!');
                                return;
                              } 
                            } 
                            if (!_cartList.contains(item)) {
                                if(_cartList.length == 0) {
                                  this.firstAddedRestId = this.currentId;
                                }
                                _cartList.add(item);
                                placeorder();

                            } else {
                                _cartList.remove(item);
                            }
                          });
                        },
                      ),
                    ),
                  ),
                ],
              ));
        }
    );
  }



  showAlertDialog(BuildContext context,String message) {

  // set up the button
  Widget okButton = FlatButton(
    child: Text("OK"),
    onPressed: () { },
  );

  // set up the AlertDialog
  AlertDialog alert = AlertDialog(
    title: Text("Error"),
    content: Text(message),
    actions: [
      okButton,
    ],
  );

  // show the dialog
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return alert;
    },
  );
}

  bool checkIfSameRestaurant(FoodItems item) {
     if(this.currentId == this.firstAddedRestId) {
       return true;
     } else {
       return false;
     }
  }

  bool checkIfNearbyRestaurant(FoodItems item) {
    var firstAddedRestaurant = this.parsedRestaurants.where((element) => element.id == this.firstAddedRestId).first;
    if(firstAddedRestaurant.nearbyresturantsidifordered.where((element) => element.id == this.currentId).toList().length > 0) {
      return true; 
    } else {
      return false;
    }
  }

  GridView _buildRestaurantsGrid() {
    return GridView.builder(
      padding: const EdgeInsets.all(4.0),
      gridDelegate:
          SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
      itemCount: parsedRestaurants.length,     
      itemBuilder: (context, index) {
        var item = parsedRestaurants[index];
        return GestureDetector(
                  onTap: () {
                    this.currentId = item.id;
                    this.setCurrentPage('Dish Screen');
                  },
                  child: Card(
                elevation: 4.0,
                child: Stack(
                  fit: StackFit.loose,
                  alignment: Alignment.center,
                  children: <Widget>[
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        // Icon(
                        //   Icons.whatshot,
                        //   color: Colors.grey,
                        //   size: 100.0,
                        // ),
                      // CircleAvatar(
                      //   backgroundColor: Colors.blueGrey,
                      //   backgroundImage: item.image.isNotEmpty
                      //    ? NetworkImage
                      //    (item.image):Icon(Icons.hotel)),
                      
                      Image.network(item.image),
              
                        Text(
                          item.name,
                          textAlign: TextAlign.center,
                          style: Theme.of(context).textTheme.subhead,
                        )
                      ],
                    ),
                  ],
                )
          ),
        );
      },
    );
  }


  // GridView _buildGridView() {
  //   return GridView.builder(
  //       padding: const EdgeInsets.all(4.0),
  //       gridDelegate:
  //           SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
  //       itemCount: _dishes.length,
  //       itemBuilder: (context, index) {
  //         var item = _dishes[index];
  //         return Card(
  //             elevation: 4.0,
  //             child: Stack(
  //               fit: StackFit.loose,
  //               alignment: Alignment.center,
  //               children: <Widget>[
  //                 Column(
  //                   mainAxisAlignment: MainAxisAlignment.center,
  //                   children: <Widget>[
  //                     Icon(
  //                       item.icon,
  //                       color: (_cartList.contains(item))
  //                           ? Colors.grey
  //                           : item.color,
  //                       size: 100.0,
  //                     ),
  //                     Text(
  //                       item.name,
  //                       textAlign: TextAlign.center,
  //                       style: Theme.of(context).textTheme.subhead,
  //                     )
  //                   ],
  //                 ),
  //                 Padding(
  //                   padding: const EdgeInsets.only(
  //                     right: 8.0,
  //                     bottom: 8.0,
  //                   ),
  //                   child: Align(
  //                     alignment: Alignment.bottomRight,
  //                     child: GestureDetector(
  //                       child: (!_cartList.contains(item))
  //                           ? Icon(
  //                               Icons.add_circle,
  //                               color: Colors.green,
  //                             )
  //                           : Icon(
  //                               Icons.remove_circle,
  //                               color: Colors.red,
  //                             ),
  //                       onTap: () {
  //                         setState(() {
  //                           if (!_cartList.contains(item))
  //                             _cartList.add(item);
  //                           else
  //                             _cartList.remove(item);
  //                         });
  //                       },
  //                     ),
  //                   ),
  //                 ),
  //               ],
  //             ));
  //       });
  // }

  // void _populateDishes() {
  //   var list = <Dish>[
  //     Dish(
  //       name: 'Chicken Zinger',
  //       icon: Icons.fastfood,
  //       color: Colors.amber,
  //     ),
  //     Dish(
  //       name: 'Chicken Zinger without chicken',
  //       icon: Icons.print,
  //       color: Colors.deepOrange,
  //     ),
  //     Dish(
  //       name: 'Rice',
  //       icon: Icons.child_care,
  //       color: Colors.brown,
  //     ),
  //     Dish(
  //       name: 'Beef burger without beef',
  //       icon: Icons.whatshot,
  //       color: Colors.green,
  //     ),
  //   ];

  //   setState(() {
  //     _dishes = list;
  //   });
  // }
void placeorder()
  {
    var restaurant = parsedRestaurants[currentId-1];
    String userId = currentfirebaseUser.uid; 
    
    Map orderinfo =
    {
      "restaurant_name": restaurant.name,
      "location": restaurant.location,
    }; 
    if (_cartList.length > 1){
    usersRef.child(userId).child("second_order").set(orderinfo); 
    }
    else{
    usersRef.child(userId).child("new_order").set(orderinfo);
    }
  }
  }

