import 'package:flutter/material.dart';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'dart:convert';


class Restaurants {
  String image;
  int id;
  String name;
  String address;
  String location;
  List<FoodItems> fooditems;
  String openingtime;
  String closingtime;
 
  List<NearbyRestaurants> nearbyresturantsidifordered;  
  

  Restaurants(this.image,this.id, this.name, this.address, this.location, this.fooditems, this.openingtime, this.closingtime,[this.nearbyresturantsidifordered]);

  factory Restaurants.fromJson(dynamic json) {
    List<FoodItems> fooditems ;

    if(json['fooditems'] != null) {
      var foodItemsJsonObj = json['fooditems'] as List;
       fooditems = foodItemsJsonObj.map((foodItemsJson) => FoodItems.fromJson(foodItemsJson)).toList();
    } else {
      fooditems = [];
    }
    


    List<NearbyRestaurants> nearbyRestaurants;

    if(json['nearbyresturantsidifordered'] != null) {
      var nearbyJsonObj = json['nearbyresturantsidifordered'] as List;
      nearbyRestaurants = nearbyJsonObj.map((nearby) => NearbyRestaurants.fromJson(nearby)).toList();
    } else {
      nearbyRestaurants = [];
    }

    return Restaurants(
      json['image'] as String,
      json['id'] as int,
      json['name'] as String,
      json['address'] as String,
      json['location'] as String,
      fooditems,
      json['openingtime'] as String,
      json['closingtime'] as String,
      nearbyRestaurants
    );

  }
}

class FoodItems {
  String name;
  String price;

  FoodItems(this.name, this.price);

  factory FoodItems.fromJson(dynamic json) {
    return FoodItems(json['name'] as String, json['price'] as String);
  }

  @override
  String toString() {
    return '{ ${this.name}, ${this.price} }';
  }
}

class NearbyRestaurants {
  int id;

  NearbyRestaurants(this.id);

  factory NearbyRestaurants.fromJson(dynamic json) {
      return NearbyRestaurants(json['id'] as int);
  }

}