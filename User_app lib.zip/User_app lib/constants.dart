import 'package:flutter/material.dart';


const kPrimaryColor = Color(0xFF66BB6A);
const kPrimaryLightColor = Color(0xFFF1E6FF);
const kSecondaryColor = Color(0xFFF06292);
