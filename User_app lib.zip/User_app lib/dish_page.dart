import 'package:flutter/material.dart';

class Dish {
  final String name;
  final IconData icon;
  final Color color;
  final String image;
  final String hotel;

  Dish({this.name, this.icon, this.color,this.image,this.hotel});
}
