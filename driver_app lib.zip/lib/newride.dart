// import 'dart:async';
// import 'package:capstone_app/mapconfig.dart';
// import 'package:capstone_app/pushnotificatiosn/ride_details.dart';
// import 'package:capstone_app/main.dart';
// import 'package:firebase_database/firebase_database.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_polyline_points/flutter_polyline_points.dart';
// import 'package:geolocator/geolocator.dart';
// import 'package:google_maps_flutter/google_maps_flutter.dart';
// import 'package:capstone_app/assistant.dart';
// import 'package:capstone_app/progressdialog.dart';



// class NewRideScreen extends StatefulWidget
// {
//   static const String idScreen = "newride";
// @override
//   _NewRideScreenState createState() => _NewRideScreenState();
// }
//  double _originLatitude = 8.908950;
// // Starting point longitude
//   double _originLongitude = 77.347321;
// // Destination latitude
//   double _destLatitude = 8.913850;
// // Destination Longitude
//   double _destLongitude = 77.384386;
// // Markers to show points on the map
//   Map<MarkerId, Marker> markers = {};
//   PolylinePoints polylinePoints = PolylinePoints();
//   Map<PolylineId, Polyline> polylines = {};

// class _NewRideScreenState extends State<NewRideScreen>
// {
  
//   Completer<GoogleMapController> _controller = Completer();
//   //GoogleMapController  newGoogleMapcontroller;
//   // Configure map position and zoom
//   static final CameraPosition _kGooglePlex = CameraPosition(
//     target: LatLng(8.908950,77.347321),
//     zoom: 9.4746,
//   ); 
   
//  @override
//   void initState() {
//     /// add origin marker origin marker
//     _addMarker(
//       LatLng(_originLatitude, _originLongitude),
//       "origin",
//       BitmapDescriptor.defaultMarker,
//     );
//     _addMarker(
//       LatLng(_destLatitude, _destLongitude),
//       "destination",
//       BitmapDescriptor.defaultMarkerWithHue(90),
//     );
//     _getPolyline();
//     super.initState();
//   }
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'Pick up the order',
//       home: Scaffold(
//         appBar: AppBar(
//           title: Text('Pick up order at Hotel'),
//         ),
//         body: GoogleMap(
//             mapType: MapType.normal,
//             initialCameraPosition: _kGooglePlex,
//             myLocationEnabled: true,
//             tiltGesturesEnabled: true,
//             compassEnabled: true,
//             scrollGesturesEnabled: true,
//             zoomGesturesEnabled: true,
//             polylines: Set<Polyline>.of(polylines.values),
//             markers: Set<Marker>.of(markers.values),
//             onMapCreated: (GoogleMapController controller) 
//             {
//               _controller.complete(controller);
//             },
//        ), 
//       ),
//     );
//   }
//  _addMarker(LatLng position, String id, BitmapDescriptor descriptor) {
//     MarkerId markerId = MarkerId(id);
//     Marker marker =
//         Marker(markerId: markerId, icon: descriptor, position: position);
//     markers[markerId] = marker;
//   }

// //_addPolyLine(List<LatLng> polylineCoordinates) {
//    _addPolyLine(List<LatLng> polylineCoordinates) {
//     PolylineId id = PolylineId("poly");
//     Polyline polyline = Polyline(
//       polylineId: id,
//       points: polylineCoordinates,
//       width: 8,
//     );
//     polylines[id] = polyline;
//     setState(() {});
//   }
//   void _getPolyline() async {
//     List<LatLng> polylineCoordinates = [];

//     PolylineResult result = await polylinePoints.getRouteBetweenCoordinates(
//       "AIzaSyAy4C8Cr-RIk_GWrcwzXGE9aREBNOGhfB0",
//       PointLatLng(_originLatitude, _originLongitude),
//       PointLatLng(_destLatitude, _destLongitude),
//       travelMode: TravelMode.driving,
//     );
//     if (result.points.isNotEmpty) {
//       result.points.forEach((PointLatLng point) {
//         polylineCoordinates.add(LatLng(point.latitude, point.longitude));
//       });
//     } else {
//       print(result.errorMessage);
//     }
//     _addPolyLine(polylineCoordinates);
//   }
// }

