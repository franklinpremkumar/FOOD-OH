import 'package:google_maps_flutter/google_maps_flutter.dart';

class Orderpickup
{
  String restaurantname;
  String usersid;
  String location;
  
  Orderpickup({this.restaurantname,this.usersid,this.location} );
}