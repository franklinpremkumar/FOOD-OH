import 'package:capstone_app/main.dart';
import 'package:capstone_app/loginscreen.dart';
import 'package:capstone_app/mainscreen.dart';
import 'package:capstone_app/mapconfig.dart';
import 'package:capstone_app/signup.dart';
import 'package:capstone_app/tab/hometab.dart';
import 'package:capstone_app/vehicleinfo.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'ride_details.dart';

class NotificationDialog extends StatelessWidget
{
  final Orderpickup orderpickup;

  NotificationDialog({this.orderpickup});

  @override
  Widget build(BuildContext context)
  {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
      backgroundColor: Colors.transparent,
      elevation: 1.0,
      child: Container(
        margin: EdgeInsets.all(5.0),
        width: double.infinity,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(5.0),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(height: 10.0),
            //Image.asset("images/uberx.png", width: 150.0,),
            SizedBox(height: 0.0,),
            Text("New order Request", style: TextStyle(fontFamily: "Brand Bold", fontSize: 20.0,),),
            SizedBox(height: 20.0),
            Padding(
              padding: EdgeInsets.all(18.0),
              child: Column(
                children: [

                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      //Image.asset("images/pickicon.png", height: 16.0, width: 16.0,),
                      SizedBox(width: 20.0,),
                      Expanded(
                        child: Container(child: Text(orderpickup.location, style: TextStyle(fontSize: 18.0),)),
                      ),
                    ],
                  ),
                  SizedBox(height: 20.0),

                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      //Image.asset("images/desticon.png", height: 16.0, width: 16.0,),
                      SizedBox(width: 20.0,),
                      Expanded(
                          child: Container(child: Text(orderpickup.restaurantname, style: TextStyle(fontSize: 18.0),))
                      ),
                    ],
                  ),
                  SizedBox(height: 0.0),

                ],
              ),
            ),

            SizedBox(height: 15.0),
            Divider(height: 2.0, thickness: 4.0,),
            SizedBox(height: 0.0),

            Padding(
              padding: EdgeInsets.all(20.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [

                  FlatButton(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18.0),
                        side: BorderSide(color: Colors.red)),
                    color: Colors.white,
                    textColor: Colors.red,
                    padding: EdgeInsets.all(8.0),
                    onPressed: ()
                    {
                    
                      Navigator.pop(context);
                    },
                    child: Text(
                      "Cancel".toUpperCase(),
                      style: TextStyle(
                        fontSize: 14.0,
                      ),
                    ),
                  ),

                  SizedBox(width: 25.0),

                  RaisedButton(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18.0),
                        side: BorderSide(color: Colors.green)),
                    onPressed: ()
                    {
                    
                      checkAvailabilityOfRide(context);
                    },
                    color: Colors.green,
                    textColor: Colors.white,
                    child: Text("Accept".toUpperCase(),
                        style: TextStyle(fontSize: 14)),
                  ),

                ],
              ),
            ),

            SizedBox(height: 0.0),
          ],
        ),
      ),
    );
  }
  
  void checkAvailabilityOfRide(context)
  {
    dashRef.once().then((DataSnapshot dataSnapShot){
      Navigator.pop(context);
      String theRideId = "";
      if(dataSnapShot.value != null)
      {
        theRideId = dataSnapShot.value.toString();
      }
      else
      {
        displayToastMessage("Ride not exists.", context);
      }


      //if(theRideId == orderpickup.)
      //{
        //dashRef.set("accepted");
        //AssistantMethods.disableHomeTabLiveLocationUpdates();
        //Navigator.push(context, MaterialPageRoute(builder: (context)=> NewRideScreen(rideDetails: orderpickup)));
      //}
      // else if(theRideId == "cancelled")
      // {
      //   displayToastMessage("Ride has been Cancelled.", context);
      // }
      // else if(theRideId == "timeout")
      // {
      //   displayToastMessage("Ride has time out.", context);
      // }
      // else
      // {
      //   displayToastMessage("Ride not exists.", context);
      // }
    });
  }
  displayToastMessage(String message, BuildContext context)
   {
     Fluttertoast.showToast(msg: message);
   }
}
