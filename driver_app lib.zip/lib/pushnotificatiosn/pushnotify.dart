
import 'package:capstone_app/main.dart';
import 'package:capstone_app/navi.dart';
import 'package:capstone_app/newride12.dart';
import 'package:capstone_app/pushnotificatiosn/ride_details.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:fcm_config/fcm_config.dart';
import 'package:capstone_app/loginscreen.dart';
import 'package:capstone_app/mainscreen.dart';
import 'package:capstone_app/mapconfig.dart';
import 'package:capstone_app/signup.dart';
import 'package:capstone_app/tab/hometab.dart';
import 'package:capstone_app/vehicleinfo.dart';
import 'dart:io' show Platform;

import 'package:google_maps_flutter/google_maps_flutter.dart';


class PushNotificationService
{
  final FirebaseMessaging firebaseMessaging = FirebaseMessaging.instance;

  Future initialize(context) async
  {
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      RemoteNotification notification = message.notification;
      AndroidNotification android = message.notification?.android; 
    });
    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      print('A new onMessageOpenedApp event was published!');
      //Navigator.pushNamed(context, '/message');
      Navigator.pushNamedAndRemoveUntil(context, NewRideScreen.idScreen, (route) => false);
          
    });
    
    
  }
  

  Future<String> getToken() async
  {
    String token = await firebaseMessaging.getToken();
    print("This is token :: " + token );
    print(token);
    driversRef.child(currentfirebaseUser.uid).child("token").set(token);
    firebaseMessaging.subscribeToTopic("alldrivers");
    firebaseMessaging.subscribeToTopic("allusers");
  }
}

void retrieverequestinfo(String usersid)
{
  newRequestsRef.child(usersid).child("new order").once().then((DataSnapshot datasnapshot)
  {
    if(datasnapshot.value != null)
    {
      String usersid=datasnapshot.value["users_id"].toString();
      String pickup= datasnapshot.value["location"].toString();
      String hotel=datasnapshot.value["restaurant_name"].toString();
      Orderpickup orderpickup = Orderpickup();

      orderpickup.usersid=usersid;
      orderpickup.location=pickup;
      orderpickup.restaurantname=hotel;

      print(orderpickup.usersid);
      print(orderpickup.location);
      print(orderpickup.restaurantname);
    }
  });
}


//   String getRideRequestId(Map<String, dynamic> message)
//   {
//     String rideRequestId = "";
//     if(Platform.isAndroid)
//     {
//        rideRequestId = message['data']['ride_request_id'];
//     }
//     else
//     {
//        rideRequestId = message['ride_request_id'];
//     }

//     return rideRequestId;
//   }

//   void retrieveRideRequestInfo(String rideRequestId, BuildContext context)
//   {
//     newRequestsRef.child(rideRequestId).once().then((DataSnapshot dataSnapShot)
//     {
//       if(dataSnapShot.value != null)
//       {
//         //assetsAudioPlayer.open(Audio("sounds/alert.mp3"));
//         //assetsAudioPlayer.play();

//         double pickUpLocationLat = double.parse(dataSnapShot.value['pickup']['latitude'].toString());
//         double pickUpLocationLng = double.parse(dataSnapShot.value['pickup']['longitude'].toString());
//         String pickUpAddress = dataSnapShot.value['pickup_address'].toString();

//         double dropOffLocationLat = double.parse(dataSnapShot.value['dropoff']['latitude'].toString());
//         double dropOffLocationLng = double.parse(dataSnapShot.value['dropoff']['longitude'].toString());
//         String dropOffAddress = dataSnapShot.value['dropoff_address'].toString();

//         String paymentMethod = dataSnapShot.value['payment_method'].toString();

//         String rider_name = dataSnapShot.value["rider_name"];
//         String rider_phone = dataSnapShot.value["rider_phone"];

//         RideDetails rideDetails = RideDetails();
//         rideDetails.ride_request_id = rideRequestId;
//         rideDetails.pickup_address = pickUpAddress;
//         rideDetails.dropoff_address = dropOffAddress;
//         rideDetails.pickup = LatLng(pickUpLocationLat, pickUpLocationLng);
//         rideDetails.dropoff = LatLng(dropOffLocationLat, dropOffLocationLng);
//         rideDetails.payment_method = paymentMethod;
//         rideDetails.rider_name = rider_name;
//         rideDetails.rider_phone = rider_phone;

//         print("Information :: ");
//         print(rideDetails.pickup_address);
//         print(rideDetails.dropoff_address);

//         showDialog(
//           context: context,
//           barrierDismissible: false,
//           builder: (BuildContext context) => NotificationDialog(rideDetails: rideDetails,),
//         );
//       }
//     });
//   }
// }