import 'package:capstone_app/loginscreen.dart';
import 'package:capstone_app/mainscreen.dart';
import 'package:capstone_app/mapconfig.dart';
import 'package:capstone_app/navi.dart';
import 'package:capstone_app/newride12.dart';
import 'package:capstone_app/signup.dart';
import 'package:capstone_app/tab/hometab.dart';
import 'package:capstone_app/vehicleinfo.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:capstone_app/newride.dart';



import 'signup.dart';


void main() async 
{
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  currentfirebaseUser=FirebaseAuth.instance.currentUser;
  //user=FirebaseAuth.instance.currentUser;
  runApp(MyApp());
}
DatabaseReference usersRef = FirebaseDatabase.instance.reference().child("users");
DatabaseReference driversRef = FirebaseDatabase.instance.reference().child("drivers");
DatabaseReference dashRef = FirebaseDatabase.instance.reference().child("drivers").child(currentfirebaseUser.uid).child("availabledrivers");
DatabaseReference newRequestsRef = FirebaseDatabase.instance.reference().child("Ride Requests");
//DatabaseReference dashRef = FirebaseDatabase.instance.reference().child("drivers").child(user.uid).child("startdash");


class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Order reciever app',
      theme: ThemeData(
        fontFamily: "raleway",

        
        primarySwatch: Colors.blue, 
        
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      initialRoute: Loginscreen.idScreen,
      routes:
      {
        Signup.idScreen: (context) => Signup(),
        VehicleInfo.idScreen: (context) => VehicleInfo(),
        Loginscreen.idScreen: (context) => Loginscreen(),
        Mainscreen.idScreen: (context) => Mainscreen(),
        NewRideScreen.idScreen: (context) => NewRideScreen()

      },
    );
  }
}
