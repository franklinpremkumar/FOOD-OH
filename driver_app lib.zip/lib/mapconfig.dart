import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:geolocator/geolocator.dart';

String mapKey = "AIzaSyAy4C8Cr-RIk_GWrcwzXGE9aREBNOGhfB0";

User firebaseUser;

User currentfirebaseUser;

//StreamSubscription<Position> hometabpagestreamsubsrciption;

StreamSubscription<Position> hometabpagestreamsubsrciption;

Position currentPosition;