import 'package:flutter/material.dart';
 
class RatingTab  extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child:Text("Rating tab page"),
      
    );
  }
}