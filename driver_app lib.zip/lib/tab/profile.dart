import 'package:flutter/material.dart';
 
class ProfileTab  extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child:Text("Profile tab page"),
      
    );
  }
}