import 'package:capstone_app/main.dart';
import 'package:capstone_app/mapconfig.dart';
import 'package:capstone_app/pushnotificatiosn/pushnotify.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_geofire/flutter_geofire.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'dart:async';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';

 
class HomeTab  extends StatefulWidget {
   
  @override
  _HomeTabState createState() => _HomeTabState();
}

class _HomeTabState extends State<HomeTab> 
{

  Completer <GoogleMapController> _controllerGooglemap = Completer();

  GoogleMapController newGooglemapController;
  
  static final CameraPosition kGooglePlex = CameraPosition
   (target: LatLng(37.425562,-122.081812),
   zoom: 14.4746,);


 

  String dasherstatustext = "Now Offline - GO ONLINE now ";

  Color dasherstatuscolor = Colors.blueAccent;

  bool isdasherAvailable = false;

  @override
    void initState() {
      super.initState();
      getcurrentdriverinfo();
    }

     Position currentPosition;
  
     var geolocator = Geolocator();

  void locatePosition() async
  {
    Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
    currentPosition = position;

    LatLng latLatposition = LatLng(position.latitude,position.longitude);
    CameraPosition cameraPosition = new CameraPosition(target: latLatposition, zoom:14);
    print("myposition= $latLatposition");
    newGooglemapController.animateCamera(CameraUpdate.newCameraPosition(cameraPosition));
  }
  void getcurrentdriverinfo () async
  {
    currentfirebaseUser= await FirebaseAuth.instance.currentUser;
    PushNotificationService pushNotificationService =PushNotificationService();
    pushNotificationService.initialize(context);
    pushNotificationService.getToken();
    }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        GoogleMap(
          
          mapType: MapType.normal,
          myLocationButtonEnabled: true,
          initialCameraPosition: kGooglePlex,
          myLocationEnabled: true,
          onMapCreated: (GoogleMapController controller)
          {
            _controllerGooglemap.complete(controller);
            newGooglemapController = controller;

            locatePosition();
            
          },
          ),
       Container(
            height: 140.0,
            width: double.infinity,
            color: Colors.black54),
            Positioned(
              top:60.0,
              left:0.0,
              right:0.0,
              child: Row(mainAxisAlignment: MainAxisAlignment.center,
                children: [
Padding(padding: EdgeInsets.symmetric(horizontal: 16.0),
            child: RaisedButton(
              onPressed: ()
            {
               if(isdasherAvailable == false)
               {
              makedriverOnlinenow();
              getlivelocation();
              
              setState(()
              {
                dasherstatuscolor=Colors.green;
                dasherstatustext ="SERVING";
                isdasherAvailable = true;
                //Fluttertoast.showToast(msg: "GOING ONLINE");
              });
                     Fluttertoast.showToast(msg: "GOING ONLINE");
              }
              else
              {
                driveroffline();
                setState(()
              {
                dasherstatuscolor=Colors.blueAccent;
                dasherstatustext ="Now Offline";
                isdasherAvailable = false;
              });
              Fluttertoast.showToast(msg: "GOING offline");

              }
            },
              
            
            color: dasherstatuscolor,
            child: Padding(padding: EdgeInsets.all(17.0),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(dasherstatustext, style: TextStyle(color:Colors.white)),
              Icon(Icons.phone_android_sharp, color: Colors.white,)
            ],),),
            )
            )
              ],)
            
            
            )
      ],
      
    );
  }

  void makedriverOnlinenow() async
  {
    //isdasherAvailable==true;
    Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
    currentPosition = position;

    Geofire.initialize("availabledrivers");
    Geofire.setLocation(currentfirebaseUser.uid, currentPosition.latitude, currentPosition.longitude);
    dashRef.onValue.listen((event)
    {
      
    });
  }

  void getlivelocation()
  {
    hometabpagestreamsubsrciption = Geolocator.getPositionStream().listen((Position position) 
    {
      currentPosition = position;
      
      Geofire.setLocation(currentfirebaseUser.uid, position.latitude, position.longitude);
      
      LatLng latLng = LatLng(position.latitude,position.longitude);
      newGooglemapController.animateCamera(CameraUpdate.newLatLng(latLng));

    
    });
  }
  void driveroffline()
  {
     Geofire.removeLocation(firebaseUser.uid);
                dashRef.onDisconnect();
                dashRef.remove();
                dashRef=null;

                Fluttertoast.showToast(msg: "Going Offline");
  }
}