import 'package:flutter/material.dart';
import 'dart:ui';

class Categories with ChangeNotifier {
  final String text;

  Categories({@required this.text});
}