import 'package:flutter/material.dart';

class AnimatedContainerModel with ChangeNotifier {
  double xOffset = 0;
  double yOffset = 0;
  double scaleFactor = 1;
  bool isDrawerOpen = false;

  AnimatedContainerModel({@required this.xOffset, @required this.yOffset, @required this.scaleFactor, @required this.isDrawerOpen});

}