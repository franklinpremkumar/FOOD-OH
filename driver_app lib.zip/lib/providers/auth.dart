import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Auth with ChangeNotifier {
  String userName = 'customer';
  String password = 'customer';
  String title = 'Sun Biosystems';
  bool _isLoggedin = false;

  setisLoggedIn(bool value) {
    this._isLoggedin = value;
  }

  bool get isLoggedIn {
    return _isLoggedin;
  }

  Future<bool> getisAuth() async {
    final prefs = await SharedPreferences.getInstance();
    if(prefs.containsKey('userData')) {
      return true;
    } else {
      return false;
    }
  }
}