import 'package:flutter/material.dart';

class GeoLocatorModel with ChangeNotifier {
    String latitude;
    String longitude;
    GeoLocatorModel({@required this.latitude, @required this.longitude});
}