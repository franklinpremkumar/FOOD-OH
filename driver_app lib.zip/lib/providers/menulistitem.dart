import 'package:flutter/material.dart';
import 'dart:ui';

class MenuListItem with ChangeNotifier {
  final String text;
  final Color fontColor;
  final double fontSize;
  final IconData itemIcon;

  MenuListItem({@required this.text, @required this.fontColor, @required this.fontSize, @required this.itemIcon});
}