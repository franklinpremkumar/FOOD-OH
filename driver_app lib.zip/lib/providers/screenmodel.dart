import 'package:flutter/material.dart';

class ScreenModel with ChangeNotifier {
  bool isDashboardScreen = true;
  bool isContactScreen = false;
  bool isSupportScreen = false;

  ScreenModel({@required this.isDashboardScreen, @required this.isContactScreen, @required this.isSupportScreen});
}