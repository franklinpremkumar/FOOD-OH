import 'package:capstone_app/providers/menulistitem.dart';
import 'package:flutter/material.dart';


class NavList with ChangeNotifier {

  bool _isCollapsed = true;
  double _screenWidth;
  double _screenHeight;

  static final List<MenuListItem> _navListItems = [
    MenuListItem(text: "Dashboard", fontColor: Colors.white, fontSize: 22, itemIcon: Icons.dashboard),
    MenuListItem(text: "Contact", fontColor: Colors.white, fontSize: 22, itemIcon: Icons.contact_phone),
    MenuListItem(text: "Support", fontColor: Colors.white, fontSize: 22, itemIcon: Icons.support),
    MenuListItem(text: "History", fontColor: Colors.white, fontSize: 22, itemIcon: Icons.history),
    MenuListItem(text: "Logout", fontColor: Colors.white, fontSize: 22, itemIcon: Icons.logout)
  ];

  List<MenuListItem> get navListItems {
    return [..._navListItems];
  }

  get isCollapsed {
    return _isCollapsed;
  }

  setIsCollapsed() {
    this._isCollapsed = !this._isCollapsed;
    notifyListeners();
  }

  get screenWidth {
    return _screenWidth;
  }

  setScreenWidthNoState(value) {
    this._screenWidth = value;
  }

  setScreenWidth(value) {
    this._screenWidth = value;
    notifyListeners();
  }

  get screenHeight {
    return _screenHeight;
  }

  setScreenHeightNoState(value) {
    this._screenHeight = value;
  }

  setScreenHeight(value) {
    this._screenHeight = value;
    notifyListeners();
  }

}