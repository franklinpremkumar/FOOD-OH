
import 'package:flutter/material.dart';

import 'animatedcontainermodel.dart';


class AnimatedContainerProvider with ChangeNotifier {

  AnimatedContainerModel _animatedContainer = new AnimatedContainerModel(xOffset: 0, yOffset: 0, scaleFactor: 1, isDrawerOpen: false);


  setAnimatedContainerModel(bool draweropen, double xoffset, double yoffset, double scalefactor) {
    _animatedContainer.isDrawerOpen = draweropen;
    _animatedContainer.xOffset = xoffset;
    _animatedContainer.yOffset = yoffset;
    _animatedContainer.scaleFactor = scalefactor;
    notifyListeners();
  }
  
  AnimatedContainerModel get animatedContainerModel {
    return this._animatedContainer;
  }




}