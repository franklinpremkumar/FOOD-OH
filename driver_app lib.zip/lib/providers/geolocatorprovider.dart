import 'package:capstone_app/providers/geolocatormodel.dart';
import 'package:flutter/material.dart';

class GeoLocatorProvider with ChangeNotifier {
  
  GeoLocatorModel _locatorModel = new GeoLocatorModel(latitude: "", longitude: "");

  setGeoLocatorModel(String latitude, String longitude) {
    _locatorModel.latitude = latitude;
    _locatorModel.longitude = longitude;
    notifyListeners();
  }

  GeoLocatorModel get geoLocatorModel {
    return this._locatorModel;
  } 

}