import 'package:capstone_app/providers/screenmodel.dart';
import 'package:flutter/material.dart';

class ScreenProvider with ChangeNotifier {
  ScreenModel _screenModel = new ScreenModel(isDashboardScreen: true, isSupportScreen: false, isContactScreen: false);

  setScreenModel(bool isDashboard, bool isSupport, bool isContact) {
    _screenModel.isDashboardScreen = isDashboard;
    _screenModel.isSupportScreen = isSupport;
    _screenModel.isContactScreen = isContact;
    notifyListeners();
  }

  ScreenModel get screenModel {
    return this._screenModel;
  }
}