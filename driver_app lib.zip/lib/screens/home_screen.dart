import 'package:capstone_app/screens/blank_screen.dart';
import 'package:capstone_app/screens/contact_screen.dart';
import 'package:capstone_app/screens/support_screen.dart';
import 'package:capstone_app/widgets/drawer_widget.dart';
import 'package:capstone_app/widgets/home_widget.dart';
import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          DrawerWidget(),
          HomeWidget()
        ],
      ),
    );
  }
}