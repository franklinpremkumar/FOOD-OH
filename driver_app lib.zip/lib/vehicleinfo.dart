import 'package:capstone_app/mainscreen.dart';
import 'package:capstone_app/mapconfig.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

import 'main.dart';

class VehicleInfo extends StatelessWidget
 {
   static const String idScreen = "vehicleinfo";
  
  TextEditingController  vehicleyeartexteditingcontroller = TextEditingController();
  TextEditingController  licensenumbertexteditingcontroller = TextEditingController();
  TextEditingController  vehicleregnumbertexteditingcontroller = TextEditingController();
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child:
      SingleChildScrollView(
        child: Column(
          children: [SizedBox(
            height: 22.0,),
            Image.asset("pics/logo.png", width: 390.0, height:250.0,),
            Padding(
              padding: EdgeInsets.fromLTRB(22.0, 22.0, 22.0, 32.0),
              child: Column(children:[
                SizedBox(height: 12.0,),
                Text("Enter vehicle Registration number",),
                SizedBox(height: 26.0,),
                TextField(
                  controller: vehicleregnumbertexteditingcontroller,
                  decoration: InputDecoration(labelText: "Vehicle number"),
                ),
                SizedBox(height: 12.0,),
                Text("Vehicle year",),
                SizedBox(height: 26.0,),
                TextField(
                  controller: vehicleyeartexteditingcontroller,
                  decoration: InputDecoration(labelText: "Vehicle year"),
                ),
                SizedBox(height: 12.0,),
                Text("Driver License number",),
                SizedBox(height: 26.0,),
                TextField(
                  controller: licensenumbertexteditingcontroller,
                  decoration: InputDecoration(labelText: "License number"),
                ), 
                SizedBox(height: 42.0,),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16.0),
                  child : RaisedButton(
                  onPressed: ()
                    {
                      if (
                        vehicleregnumbertexteditingcontroller.text.isEmpty
                      )
                      {
                    displayToastMessage("Please enter your vehicle registration number", context);
                      }
                      else if (
                        vehicleregnumbertexteditingcontroller.text.isEmpty
                      )
                      {
                    displayToastMessage("Please enter a valid vehicle year", context);
                      }
                      else if (
                        licensenumbertexteditingcontroller.text.isEmpty
                      )
                      {
                    displayToastMessage("Please enter a valid license number", context);
                      }
                      else{
                        
                    savevehicleinfo(context);

                      }
                      
                    },
                    color: Theme.of(context).accentColor,
                    child: Padding(
                    padding: EdgeInsets.all(17.0),
                    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text ("SIGNUP"),
                      Icon(Icons.arrow_forward)
                    ],),
                    ),
                    
                    
                  )
                )
              ],),
            ),
      ],
      ),
      ),
      ),
      
    );
  }
  void savevehicleinfo(context)
  {
    //print (currentfirebaseUser);
    String userId = currentfirebaseUser.uid;
    //String user1 = user.uid;

    Map vehicleInfomap = 
    {
      "vehicle_number" : vehicleregnumbertexteditingcontroller.text,
      "vehicle year" : vehicleyeartexteditingcontroller.text,
      "License number" : licensenumbertexteditingcontroller.text,
    };
    driversRef.child(userId).child("vehicle_details").set(vehicleInfomap); 
    
    Navigator.pushNamedAndRemoveUntil(context, Mainscreen.idScreen, (route) => false);

  }
  displayToastMessage(String message, BuildContext context)
   {
     Fluttertoast.showToast(msg: message);
   }

}