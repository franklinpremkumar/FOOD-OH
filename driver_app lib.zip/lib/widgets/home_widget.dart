import 'package:capstone_app/providers/animatedcontainerprovider.dart';
import 'package:capstone_app/providers/geolocatorprovider.dart';
import 'package:capstone_app/providers/screenprovider.dart';
import 'package:capstone_app/screens/blank_screen.dart';
import 'package:capstone_app/screens/contact_screen.dart';
import 'package:provider/provider.dart';
import 'package:capstone_app/screens/support_screen.dart';
import 'package:capstone_app/widgets/dashboard_widget.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

class HomeWidget extends StatefulWidget {

  @override
  _HomeWidgetState createState() => _HomeWidgetState();
}

class _HomeWidgetState extends State<HomeWidget> {

  String latitudeData = "";
  String longitudeData = ""; 
  // double xOffset = 0;
  // double yOffset = 0;
  // double scaleFactor = 1;
  // bool isDrawerOpen = false;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    this.getCurrentLocation();
  }

  getCurrentLocation() async {
    final geoposition = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
    var latData = '${geoposition.latitude}';
    var longData = '${geoposition.longitude}';
    Provider.of<GeoLocatorProvider>(context, listen: false).setGeoLocatorModel(latData, longData);
  }

  @override
  Widget build(BuildContext context) {
    var animatedContainerProvider =
        Provider.of<AnimatedContainerProvider>(context, listen: false);
    return Consumer<AnimatedContainerProvider>(
      builder: (ctx, animatedContainer, _) => (AnimatedContainer(
        transform: Matrix4.translationValues(
            animatedContainer.animatedContainerModel.xOffset,
            animatedContainer.animatedContainerModel.yOffset,
            0)
          ..scale(animatedContainer.animatedContainerModel.scaleFactor)
          ..rotateY(
              animatedContainer.animatedContainerModel.isDrawerOpen ? -0.5 : 0),
        duration: Duration(milliseconds: 250),
        decoration: BoxDecoration(
          color: Colors.grey[200],
          borderRadius: BorderRadius.circular(
              animatedContainer.animatedContainerModel.isDrawerOpen ? 40 : 0.0),
        ),
        child: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(
                height: 50,
              ),
              Container(
                margin: EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    animatedContainer.animatedContainerModel.isDrawerOpen
                        ? IconButton(
                            icon: Icon(Icons.arrow_back_ios),
                            onPressed: () {
                              animatedContainerProvider
                                  .setAnimatedContainerModel(false, 0, 0, 1);
                              // setState(() {
                              // xOffset = 0;
                              // yOffset = 0;
                              // scaleFactor = 1;
                              // isDrawerOpen = false;
                              // });
                            })
                        : IconButton(
                            icon: Icon(Icons.menu),
                            onPressed: () {
                              animatedContainerProvider
                                  .setAnimatedContainerModel(
                                      true, 230, 150, 0.6);
                              // setState(() {
                              //   xOffset = 230;
                              //   yOffset = 150;
                              //   scaleFactor = 0.6;
                              //   isDrawerOpen = true;
                              // });
                            }),
                    Consumer<GeoLocatorProvider>(
                        builder: (ctx, geolocatorprovider, _) => Column(
                        children: [
                          Text('Location'),
                          Row(
                            children: [
                              Icon(Icons.location_on, color: Colors.teal),
                              Text(geolocatorprovider.geoLocatorModel.latitude),
                              Text(geolocatorprovider.geoLocatorModel.longitude),
                            ],
                          ),
                        ],
                      ),
                    ),
                    CircleAvatar()
                  ],
                ),
              ),
              Consumer<ScreenProvider>(
                builder: (ctx, screenProvider, _) => screenProvider.screenModel.isDashboardScreen ? DashboardWidget() : 
                screenProvider.screenModel.isContactScreen ? ContactScreen() : screenProvider.screenModel.isSupportScreen ? SupportScreen() : BlankScreen(),
              ),
              // widget.isDashboardScreen
              //     ? DashboardWidget()
              //     : widget.isContactScreen
              //         ? ContactScreen()
              //         : widget.isSupportScreen
              //             ? SupportScreen()
              //             : BlankScreen()
            ],
          ),
        ),
      )),
    );
  }
}
