import 'package:capstone_app/screens/detailed_screen.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

class DashboardWidget extends StatefulWidget {
  @override
  _DashboardWidgetState createState() => _DashboardWidgetState();
}

class _DashboardWidgetState extends State<DashboardWidget> {

    List<String> lstCategories = [
    'FOOD1',
    'FOOD2',
    'FOOD3',
    'FOOD4',
    'FOOD5',
    'FOOD6',
    'FOOD7',
    'FOOD8',
    'FOOD9',
    'FOOD10'
  ];

  List<String> lstProfilePics = [
    'pics/biriyani.jpg',
    'pics/burgers.jpg',
    'pics/food.jpg',
    'pics/pizzas.jpg',
    'pics/veg.jpg'
  ];

  List<BoxShadow> shadowList = [
    BoxShadow(color: Colors.grey[300], blurRadius: 30, offset: Offset(0, 10)),
  ];
  
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
         Container(
              padding: EdgeInsets.symmetric(horizontal: 20, vertical: 15),
              margin: EdgeInsets.symmetric(vertical: 30, horizontal: 20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Icon(Icons.search),
                  Text('Search for restaurants'),
                  Icon(Icons.settings)
                ],
              ),
            ),
            Container(
              height: 120,
              child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: lstCategories.length,
                  itemBuilder: (context, index) {
                    return Container(
                      child: Column(
                        children: [
                          Container(
                            padding: EdgeInsets.all(10),
                            margin: EdgeInsets.only(left: 20),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              boxShadow: shadowList,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            height: 50,
                            width: 50,
                            // put image below
                            child: Icon(Icons.emoji_food_beverage_outlined),
                          ),
                          Text(lstCategories[index]),
                        ],
                      ),
                    );
                  }),
            ),
            GestureDetector(
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => DetailedScreen()));
                },
                child: Container(
                height: 200,
                margin: EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  children: [
                    Expanded(
                      child: Stack(
                        children: [
                          Container(
                            decoration: BoxDecoration(
                                image: DecorationImage(
                                  image: AssetImage(
                                      'pics/biriyani.jpg'),
                                  fit: BoxFit.fill,
                                ),
                                color: Colors.blueGrey[300],
                                borderRadius: BorderRadius.circular(20),
                                boxShadow: shadowList),
                            margin: EdgeInsets.only(top: 10),
                          ),
                          // Align(
                          //   child: Image.asset('assets/images/profilepic3.jpeg',
                          //   fit: BoxFit.fitWidth,)
                          // ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: Container(
                        margin: EdgeInsets.only(top: 60, bottom: 20),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          boxShadow: shadowList,
                          borderRadius: BorderRadius.only(
                              topRight: Radius.circular(20),
                              bottomRight: Radius.circular(20)),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Container(
              height: 200,
              margin: EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                children: [
                  Expanded(
                    child: Stack(
                      children: [
                        Container(
                          decoration: BoxDecoration(
                              image: DecorationImage(
                                image: AssetImage(
                                    'pics/burgers.jpg'),
                                fit: BoxFit.fill,
                              ),
                              color: Colors.blueGrey[300],
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: shadowList),
                          margin: EdgeInsets.only(top: 40),
                        ),
                        // Align(
                        //   child: Image.asset('assets/images/profilepic3.jpeg',
                        //   fit: BoxFit.fitWidth,)
                        // ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Container(
                      margin: EdgeInsets.only(top: 60, bottom: 20),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        boxShadow: shadowList,
                        borderRadius: BorderRadius.only(
                            topRight: Radius.circular(20),
                            bottomRight: Radius.circular(20)),
                      ),
                    ),
                  ),
                ],
              ),
            ),
      ],
    );
  }
}