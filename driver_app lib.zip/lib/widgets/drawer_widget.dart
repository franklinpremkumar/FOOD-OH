import 'package:capstone_app/providers/animatedcontainerprovider.dart';
import 'package:capstone_app/providers/navlist.dart';
import 'package:capstone_app/providers/screenprovider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class DrawerWidget extends StatefulWidget {

  final Color backgroundColor = Color(0xFF040458);
  @override
  _DrawerWidgetState createState() => _DrawerWidgetState();
}

class _DrawerWidgetState extends State<DrawerWidget> {
  @override
  Widget build(BuildContext context) {
    var screenprovider = Provider.of<ScreenProvider>(context, listen: false);
    var animatedcontainerprovider = Provider.of<AnimatedContainerProvider>(context, listen: false);
    return Container(
      color: widget.backgroundColor,
      padding: EdgeInsets.only(top: 50, bottom: 70, left: 10),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              CircleAvatar(),
              SizedBox(width: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Customer name', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                  Text('Status', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                ],
              ),
            ],
          ),
          Consumer<NavList>(
            builder: (ctx, navList, _) => Column(
              children: navList.navListItems.map((element) => Padding(
                padding: const EdgeInsets.all(8.0),
                child: GestureDetector(
                  onTap: ()  {
                    animatedcontainerprovider.setAnimatedContainerModel(false, 0, 0, 1);
                    if(element.text == "Dashboard") {
                       screenprovider.setScreenModel(true, false, false);
                    } else if(element.text == "Support") {
                       screenprovider.setScreenModel(false, true, false);
                    } else if(element.text == "Contact") {
                       screenprovider.setScreenModel(false, false, true);
                    }
                  },
                  child: Row(
                    children: [
                      Icon(Icons.support,color: Colors.white),
                      SizedBox(width: 10,),
                      Text(element.text, style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 20),),
                    ],
                  ),
                ),
              ),).toList(),
            ),
          ),
          Row(
            children: [
              Icon(Icons.settings, color: Colors.white),
              SizedBox(width: 10,),
              Text('Settings', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold,),),
              SizedBox(width: 10,),
              Container(width: 2, height: 20,color: Colors.white),
              SizedBox(width: 10,),
              Text('Log out', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold,),),
            ],
          ),
        ],
      ),
    );
  }
}