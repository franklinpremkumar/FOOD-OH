import 'package:capstone_app/mainscreen.dart';
import 'package:capstone_app/signup.dart';
import 'package:flutter/material.dart';



 class Loginscreen extends StatelessWidget {
   static const idScreen = "login";
   @override
   Widget build(BuildContext context) {
     return Scaffold(
       backgroundColor: Colors.white,
       body: Column(
         children: [
           SizedBox(height: 105.0,),
           Image(
             image: AssetImage("pics/logo.png"),
             width: 450.0,
             height: 150.0,
             alignment: Alignment.center, 
             ),
             SizedBox(height: 50.0,),
             Text("Login as a Driver",
             style: TextStyle(fontSize: 24.0),
             textAlign: TextAlign.center,
             ),
             SizedBox(height: 30.0,),
             TextField(
               keyboardType: TextInputType.emailAddress,
               decoration: InputDecoration(
                 labelText: "Enter your email",
                 labelStyle: TextStyle(fontSize: 14.0,
                 ),
                 hintStyle: TextStyle(color: Colors.blueGrey,
                 fontSize: 14.0,
                 ),
                 
               ),
               style: TextStyle(fontSize: 14.0),
             ), 
             SizedBox(height: 30.0,),
             TextField(
               keyboardType: TextInputType.visiblePassword,
               decoration: InputDecoration(
                 labelText: "Enter your password",
                 labelStyle: TextStyle(fontSize: 14.0,
                 ),
                 hintStyle: TextStyle(color: Colors.blueGrey,
                 fontSize: 14.0,
                 ),
                 
               ),
               style: TextStyle(fontSize: 14.0),
             ),
             SizedBox(height: 50.0,),
             RaisedButton(
               color: Colors.yellow,
               textColor: Colors.black,
             child: Container(
               height: 50.0,
               child: Center(
                 child: Text(
                   "LOGIN",
                   style: TextStyle(fontSize: 18.0),
                 ),
               ),
             ),
             onPressed: ()
             {
               print("Login successful");
               Navigator.pushNamedAndRemoveUntil(context, Mainscreen.idScreen, (route) => false);
             },
             ),
             FlatButton(
               onPressed: ()
               {
                 Navigator.pushNamedAndRemoveUntil(context, Signup.idScreen, (route) => false);
               },
               child: Text(" Don't have an account, Sign up"),
               ),
         ],
       ),
     );
   }
 }