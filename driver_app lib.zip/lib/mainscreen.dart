


import 'package:capstone_app/tab/hometab.dart';
import 'package:capstone_app/tab/profile.dart';
import 'package:capstone_app/tab/rating.dart';
import 'package:flutter/material.dart';


class Mainscreen extends StatefulWidget
 {
  static const String idScreen = "mainscreen";
  @override
  _MainscreenState createState() => _MainscreenState();
}

class _MainscreenState extends State<Mainscreen> with SingleTickerProviderStateMixin
{
  TabController tabController;
  int selectedIndex = 0;

  void onItemclicked (int index)
  {
    setState(() {
      selectedIndex = index;
      tabController.index = selectedIndex;
    });
  }

    void initState() 
    {
      super.initState();
       tabController = TabController(length: 3, vsync: this); 
    }
  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    tabController.dispose();
  }

  @override
  Widget build(BuildContext context){
    return Scaffold(
    body: TabBarView(
       physics: NeverScrollableScrollPhysics(),
       controller: tabController,
       children: [
        HomeTab(),
        RatingTab(),
        ProfileTab(),
      ],
    ),
    bottomNavigationBar: BottomNavigationBar(
    items: <BottomNavigationBarItem>
     [

    BottomNavigationBarItem(
    icon: Icon(Icons.home),
    label: "HOME"),
    
    BottomNavigationBarItem(
      icon: Icon(Icons.star),
    label: "RATING"),
    BottomNavigationBarItem(
      icon: Icon(Icons.person),
    label: "PROFILE")
    ],
    unselectedItemColor: Colors.black38,
    selectedItemColor: Colors.blueAccent,
    type: BottomNavigationBarType.fixed,
    showUnselectedLabels: true,
    currentIndex: selectedIndex,
    onTap: onItemclicked,
    )

    );
  }

} 